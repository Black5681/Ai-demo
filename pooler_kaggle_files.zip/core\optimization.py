import torch
import torch.nn as nn
from typing import Dict, Any, List, Optional
import numpy as np
from dataclasses import dataclass

@dataclass
class OptimizationMetrics:
    accuracy: float
    latency: float
    memory_usage: float
    gpu_usage: float
    throughput: float

class SelfOptimizationSystem:
    def __init__(self):
        self.performance_tracker = PerformanceTracker()
        self.hyperparameter_tuner = HyperparameterTuner()
        self.resource_optimizer = ResourceOptimizer()
        self.scaling_manager = ScalingManager()
        
        # Optimization thresholds
        self.thresholds = {
            "accuracy": 0.9,
            "latency": 100,  # ms
            "memory": 0.8,   # percentage
            "gpu": 0.9,      # percentage
            "throughput": 100  # requests/sec
        }
    
    async def optimize(self, model: nn.Module, metrics: OptimizationMetrics) -> Dict[str, Any]:
        """Perform full optimization cycle."""
        # Track performance
        performance_data = await self.performance_tracker.track(metrics)
        
        # Check if optimization needed
        if self._needs_optimization(performance_data):
            # Tune hyperparameters
            tuning_results = await self.hyperparameter_tuner.tune(model)
            
            # Optimize resources
            resource_config = await self.resource_optimizer.optimize(metrics)
            
            # Adjust scaling
            scaling_decision = await self.scaling_manager.adjust(metrics)
            
            return {
                "performance": performance_data,
                "tuning": tuning_results,
                "resources": resource_config,
                "scaling": scaling_decision
            }
        
        return {"status": "optimal", "metrics": metrics}
    
    def _needs_optimization(self, performance: Dict[str, float]) -> bool:
        """Check if optimization is needed."""
        return any(
            performance.get(metric, 0) < threshold
            for metric, threshold in self.thresholds.items()
        )

class PerformanceTracker:
    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        self.metrics_history = []
        
    async def track(self, metrics: OptimizationMetrics) -> Dict[str, float]:
        """Track performance metrics."""
        # Add new metrics
        self.metrics_history.append(metrics)
        
        # Keep only recent history
        if len(self.metrics_history) > self.window_size:
            self.metrics_history.pop(0)
        
        # Calculate statistics
        return {
            "accuracy": self._calculate_average("accuracy"),
            "latency": self._calculate_average("latency"),
            "memory_usage": self._calculate_average("memory_usage"),
            "gpu_usage": self._calculate_average("gpu_usage"),
            "throughput": self._calculate_average("throughput"),
            "stability": self._calculate_stability()
        }
    
    def _calculate_average(self, metric: str) -> float:
        """Calculate average for a metric."""
        values = [getattr(m, metric) for m in self.metrics_history]
        return sum(values) / len(values) if values else 0.0
    
    def _calculate_stability(self) -> float:
        """Calculate system stability score."""
        if not self.metrics_history:
            return 1.0
        
        # Calculate variance of key metrics
        variances = []
        for metric in ["accuracy", "latency", "throughput"]:
            values = [getattr(m, metric) for m in self.metrics_history]
            variance = np.var(values) if len(values) > 1 else 0
            variances.append(variance)
        
        # Convert to stability score (1 - normalized variance)
        return 1.0 - min(sum(variances) / len(variances), 1.0)

class HyperparameterTuner:
    def __init__(self):
        self.param_ranges = {
            "learning_rate": (1e-5, 1e-2),
            "batch_size": (16, 256),
            "num_layers": (2, 12),
            "hidden_size": (64, 512)
        }
        
    async def tune(self, model: nn.Module) -> Dict[str, Any]:
        """Tune model hyperparameters."""
        current_params = self._get_current_params(model)
        
        # Bayesian optimization for parameter search
        optimized_params = await self._bayesian_optimize(current_params)
        
        # Apply new parameters
        await self._apply_params(model, optimized_params)
        
        return {
            "old_params": current_params,
            "new_params": optimized_params,
            "improvement": self._calculate_improvement(current_params, optimized_params)
        }
    
    def _get_current_params(self, model: nn.Module) -> Dict[str, float]:
        """Get current model parameters."""
        return {
            "learning_rate": getattr(model, "lr", 0.001),
            "batch_size": getattr(model, "batch_size", 32),
            "num_layers": len([m for m in model.modules() if isinstance(m, nn.Linear)]),
            "hidden_size": next(model.parameters()).size(0)
        }
    
    async def _bayesian_optimize(self, current_params: Dict[str, float]) -> Dict[str, float]:
        """Perform Bayesian optimization."""
        # Placeholder for actual Bayesian optimization
        # In practice, this would use a proper Bayesian optimization library
        optimized = current_params.copy()
        for param, (min_val, max_val) in self.param_ranges.items():
            current = current_params[param]
            # Simple random exploration around current value
            optimized[param] = max(min_val, min(max_val, 
                current * (1 + 0.1 * (np.random.random() - 0.5))))
        return optimized
    
    async def _apply_params(self, model: nn.Module, params: Dict[str, float]):
        """Apply new parameters to model."""
        for name, value in params.items():
            if hasattr(model, name):
                setattr(model, name, value)
    
    def _calculate_improvement(self, old: Dict[str, float], 
                             new: Dict[str, float]) -> float:
        """Calculate improvement score."""
        improvements = []
        for param in old:
            old_val, new_val = old[param], new[param]
            min_val, max_val = self.param_ranges[param]
            normalized_old = (old_val - min_val) / (max_val - min_val)
            normalized_new = (new_val - min_val) / (max_val - min_val)
            improvements.append(abs(normalized_new - normalized_old))
        return sum(improvements) / len(improvements)

class ResourceOptimizer:
    def __init__(self):
        self.resource_limits = {
            "memory": 0.9,  # 90% of available
            "gpu": 0.95,    # 95% of available
            "cpu": 0.8      # 80% of available
        }
        
    async def optimize(self, metrics: OptimizationMetrics) -> Dict[str, Any]:
        """Optimize resource usage."""
        current_usage = {
            "memory": metrics.memory_usage,
            "gpu": metrics.gpu_usage,
            "cpu": metrics.latency / 100  # Approximate CPU usage
        }
        
        # Calculate optimal resource allocation
        optimal_allocation = await self._calculate_optimal_allocation(current_usage)
        
        # Generate resource configuration
        config = await self._generate_config(optimal_allocation)
        
        return {
            "current_usage": current_usage,
            "optimal_allocation": optimal_allocation,
            "config": config
        }
    
    async def _calculate_optimal_allocation(self, 
                                         current: Dict[str, float]) -> Dict[str, float]:
        """Calculate optimal resource allocation."""
        optimal = {}
        for resource, usage in current.items():
            limit = self.resource_limits[resource]
            if usage > limit:
                # Need to reduce
                optimal[resource] = limit
            else:
                # Can potentially increase
                optimal[resource] = min(usage * 1.2, limit)
        return optimal
    
    async def _generate_config(self, 
                             allocation: Dict[str, float]) -> Dict[str, Any]:
        """Generate resource configuration."""
        return {
            "memory_limit": f"{int(allocation['memory'] * 100)}%",
            "gpu_limit": f"{int(allocation['gpu'] * 100)}%",
            "cpu_limit": f"{int(allocation['cpu'] * 100)}%",
            "priority": "high" if max(allocation.values()) > 0.8 else "normal"
        }

class ScalingManager:
    def __init__(self):
        self.min_instances = 1
        self.max_instances = 10
        self.scale_up_threshold = 0.8
        self.scale_down_threshold = 0.3
        
    async def adjust(self, metrics: OptimizationMetrics) -> Dict[str, Any]:
        """Adjust scaling based on metrics."""
        # Calculate load
        load = max(metrics.memory_usage, metrics.gpu_usage)
        
        # Determine scaling action
        if load > self.scale_up_threshold:
            action = "scale_up"
        elif load < self.scale_down_threshold:
            action = "scale_down"
        else:
            action = "maintain"
        
        # Calculate target instances
        current_instances = self._get_current_instances()
        target_instances = self._calculate_target_instances(current_instances, action)
        
        return {
            "action": action,
            "current_instances": current_instances,
            "target_instances": target_instances,
            "load": load
        }
    
    def _get_current_instances(self) -> int:
        """Get current number of instances."""
        # Placeholder - in practice, would get from infrastructure
        return 1
    
    def _calculate_target_instances(self, current: int, action: str) -> int:
        """Calculate target number of instances."""
        if action == "scale_up":
            return min(current * 2, self.max_instances)
        elif action == "scale_down":
            return max(current // 2, self.min_instances)
        return current
