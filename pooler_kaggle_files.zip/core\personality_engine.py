from typing import Dict, Tuple
import numpy as np
from .instance_manager import Personality, EmotionalState

class PersonalityEngine:
    def __init__(self):
        self.emotion_keywords = {
            'joy': (0.8, 0.6, 0.7),      # valence, arousal, dominance
            'sadness': (-0.7, 0.3, 0.3),
            'anger': (-0.6, 0.8, 0.8),
            'fear': (-0.7, 0.7, 0.2),
            'surprise': (0.4, 0.8, 0.5),
            'disgust': (-0.5, 0.5, 0.6),
        }

    def adjust_response(self, text: str, personality: Personality, emotional_state: EmotionalState) -> str:
        """Adjust response based on personality and emotional state."""
        # Personality-based adjustments
        if personality.extraversion > 0.7:
            text = self._make_more_extroverted(text)
        if personality.agreeableness > 0.7:
            text = self._make_more_agreeable(text)
        if personality.neuroticism > 0.7:
            text = self._add_uncertainty(text)

        # Emotional state adjustments
        if emotional_state.valence > 0.7:
            text = self._add_positive_emotion(text)
        elif emotional_state.valence < -0.3:
            text = self._add_negative_emotion(text)

        if emotional_state.arousal > 0.7:
            text = self._increase_intensity(text)

        return text

    def update_emotional_state(self, 
                             current_state: EmotionalState,
                             input_text: str,
                             personality: Personality) -> EmotionalState:
        """Update emotional state based on input text and personality."""
        # Calculate emotion scores from input text
        emotion_scores = self._analyze_text_emotion(input_text)
        
        # Personality influence on emotion change
        personality_factor = self._calculate_personality_factor(personality)
        
        # Update emotional state with decay and new input
        new_valence = self._update_emotion_component(
            current_state.valence,
            emotion_scores['valence'],
            personality_factor
        )
        new_arousal = self._update_emotion_component(
            current_state.arousal,
            emotion_scores['arousal'],
            personality_factor
        )
        new_dominance = self._update_emotion_component(
            current_state.dominance,
            emotion_scores['dominance'],
            personality_factor
        )

        return EmotionalState(
            valence=new_valence,
            arousal=new_arousal,
            dominance=new_dominance
        )

    def _analyze_text_emotion(self, text: str) -> Dict[str, float]:
        """Analyze text for emotional content."""
        text = text.lower()
        total_valence = 0
        total_arousal = 0
        total_dominance = 0
        count = 0

        for emotion, (v, a, d) in self.emotion_keywords.items():
            if emotion in text:
                total_valence += v
                total_arousal += a
                total_dominance += d
                count += 1

        if count == 0:
            return {'valence': 0, 'arousal': 0.5, 'dominance': 0.5}

        return {
            'valence': total_valence / count,
            'arousal': total_arousal / count,
            'dominance': total_dominance / count
        }

    def _calculate_personality_factor(self, personality: Personality) -> float:
        """Calculate how much personality influences emotion changes."""
        # Higher neuroticism means emotions change more easily
        base_factor = 0.5
        neuroticism_influence = personality.neuroticism * 0.3
        return base_factor + neuroticism_influence

    def _update_emotion_component(self, 
                                current: float, 
                                new: float, 
                                personality_factor: float,
                                decay: float = 0.9) -> float:
        """Update a single emotion component with decay."""
        current_decayed = current * decay
        delta = new - current_decayed
        return current_decayed + (delta * personality_factor)

    # Response modification methods
    def _make_more_extroverted(self, text: str) -> str:
        """Add more enthusiastic and social elements to text."""
        if not text.endswith(('!', '?')):
            text += '!'
        return text

    def _make_more_agreeable(self, text: str) -> str:
        """Make the text more agreeable and sympathetic."""
        if len(text) > 0:
            text = "I understand. " + text
        return text

    def _add_uncertainty(self, text: str) -> str:
        """Add elements of uncertainty to text."""
        uncertainty_phrases = ["I think ", "Perhaps ", "Maybe "]
        return np.random.choice(uncertainty_phrases) + text

    def _add_positive_emotion(self, text: str) -> str:
        """Add positive emotional markers to text."""
        positive_markers = [" 😊", " Great!", " I'm happy to help!"]
        return text + np.random.choice(positive_markers)

    def _add_negative_emotion(self, text: str) -> str:
        """Add negative emotional markers to text."""
        return "I'm a bit concerned. " + text

    def _increase_intensity(self, text: str) -> str:
        """Increase the emotional intensity of the text."""
        return text.replace('.', '!')
