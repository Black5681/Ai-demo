import time
from typing import Dict, List, Optional
import threading
import json
from datetime import datetime
import pytz
from prometheus_client import Counter, Histogram, Gauge
from google.cloud import bigquery
from google.cloud import logging as gcp_logging
import psutil

class PerformanceMetrics:
    def __init__(self, project_id: str = "pooler-ai-project"):
        # Prometheus metrics
        self.api_requests = Counter('api_requests_total', 'Total API requests', ['endpoint', 'status'])
        self.response_time = Histogram('response_time_seconds', 'Response time in seconds', ['endpoint'])
        self.active_instances = Gauge('active_instances', 'Number of active AI instances', ['model_type'])
        self.instance_load = Gauge('instance_load_percent', 'Load percentage of AI instances', ['instance_id'])
        self.memory_usage = Gauge('memory_usage_bytes', 'Memory usage in bytes', ['instance_id'])
        
        # New health metrics
        self.system_cpu = Gauge('system_cpu_percent', 'System CPU usage percentage')
        self.system_memory = Gauge('system_memory_percent', 'System memory usage percentage')
        self.system_disk = Gauge('system_disk_percent', 'System disk usage percentage')
        self.error_count = Counter('error_count_total', 'Total error count', ['severity', 'category'])
        self.health_check_status = Gauge('health_check_status', 'Health check status (1=healthy, 0=unhealthy)')
        
        # Google Cloud setup
        self.project_id = project_id
        self.bigquery_client = bigquery.Client(project=project_id)
        self.logging_client = gcp_logging.Client(project=project_id)
        self.logger = self.logging_client.logger('pooler-ai-metrics')
        
        # In-memory metrics for quick access
        self.metrics_cache: Dict[str, List[Dict]] = {
            'response_times': [],
            'api_usage': {},
            'instance_loads': {}
        }
        
        # Background thread for periodic flushing to BigQuery
        self.flush_thread = threading.Thread(target=self._periodic_flush, daemon=True)
        self.flush_thread.start()
        
        # Background thread for periodic health monitoring
        self.health_thread = threading.Thread(target=self.start_health_monitoring, daemon=True)
        self.health_thread.start()
    
    def record_api_request(self, endpoint: str, status: int, duration: float):
        """Record an API request with its status and duration."""
        self.api_requests.labels(endpoint=endpoint, status=str(status)).inc()
        self.response_time.labels(endpoint=endpoint).observe(duration)
        
        timestamp = datetime.now(pytz.UTC).isoformat()
        
        # Add to in-memory cache
        self.metrics_cache['response_times'].append({
            'timestamp': timestamp,
            'endpoint': endpoint,
            'status': status,
            'duration': duration
        })
        
        # Update API usage statistics
        if endpoint not in self.metrics_cache['api_usage']:
            self.metrics_cache['api_usage'][endpoint] = {'count': 0, 'total_duration': 0}
        
        self.metrics_cache['api_usage'][endpoint]['count'] += 1
        self.metrics_cache['api_usage'][endpoint]['total_duration'] += duration
        
        # Log to Google Cloud Logging
        self.logger.log_struct({
            'endpoint': endpoint,
            'status': status,
            'duration_ms': duration * 1000,
            'timestamp': timestamp
        })
    
    def update_instance_metrics(self, instance_id: str, model_type: str, load_percent: float, memory_bytes: int):
        """Update metrics for a specific AI instance."""
        self.active_instances.labels(model_type=model_type).inc()
        self.instance_load.labels(instance_id=instance_id).set(load_percent)
        self.memory_usage.labels(instance_id=instance_id).set(memory_bytes)
        
        timestamp = datetime.now(pytz.UTC).isoformat()
        
        # Update in-memory cache
        self.metrics_cache['instance_loads'][instance_id] = {
            'timestamp': timestamp,
            'model_type': model_type,
            'load_percent': load_percent,
            'memory_bytes': memory_bytes
        }
        
        # Log to Google Cloud Logging
        self.logger.log_struct({
            'instance_id': instance_id,
            'model_type': model_type,
            'load_percent': load_percent,
            'memory_bytes': memory_bytes,
            'timestamp': timestamp
        })
    
    def get_api_statistics(self) -> Dict:
        """Get current API usage statistics."""
        return {
            'total_requests': sum(endpoint['count'] for endpoint in self.metrics_cache['api_usage'].values()),
            'endpoints': self.metrics_cache['api_usage'],
            'avg_response_time': self._calculate_avg_response_time()
        }
    
    def get_instance_statistics(self) -> Dict:
        """Get current instance load statistics."""
        model_counts = {}
        avg_loads = {}
        
        for instance_id, data in self.metrics_cache['instance_loads'].items():
            model_type = data['model_type']
            if model_type not in model_counts:
                model_counts[model_type] = 0
                avg_loads[model_type] = 0
            
            model_counts[model_type] += 1
            avg_loads[model_type] += data['load_percent']
        
        # Calculate averages
        for model_type in avg_loads:
            if model_counts[model_type] > 0:
                avg_loads[model_type] /= model_counts[model_type]
        
        return {
            'total_instances': len(self.metrics_cache['instance_loads']),
            'model_distribution': model_counts,
            'average_loads': avg_loads,
            'instances': self.metrics_cache['instance_loads']
        }
    
    def _calculate_avg_response_time(self) -> float:
        """Calculate average response time from cached data."""
        if not self.metrics_cache['response_times']:
            return 0
        
        total_duration = sum(item['duration'] for item in self.metrics_cache['response_times'])
        return total_duration / len(self.metrics_cache['response_times'])
    
    def _periodic_flush(self):
        """Periodically flush metrics to BigQuery."""
        while True:
            time.sleep(300)  # Flush every 5 minutes
            self._flush_to_bigquery()
    
    def _flush_to_bigquery(self):
        """Flush cached metrics to BigQuery."""
        try:
            # Prepare response time data
            if self.metrics_cache['response_times']:
                table_id = f"{self.project_id}.pooler_ai_metrics.response_times"
                errors = self.bigquery_client.insert_rows_json(
                    table_id, 
                    self.metrics_cache['response_times']
                )
                if not errors:
                    self.metrics_cache['response_times'] = []
            
            # Prepare instance load data
            if self.metrics_cache['instance_loads']:
                instance_loads = [
                    {**data, 'instance_id': instance_id}
                    for instance_id, data in self.metrics_cache['instance_loads'].items()
                ]
                
                table_id = f"{self.project_id}.pooler_ai_metrics.instance_loads"
                self.bigquery_client.insert_rows_json(table_id, instance_loads)
        except Exception as e:
            print(f"Error flushing metrics to BigQuery: {e}")
    
    def update_health_metrics(self):
        """Update system health metrics."""
        try:
            # Update CPU metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            self.system_cpu.set(cpu_percent)
            
            # Update memory metrics
            memory = psutil.virtual_memory()
            self.system_memory.set(memory.percent)
            
            # Update disk metrics
            disk = psutil.disk_usage('/')
            self.system_disk.set(disk.percent)
            
            # Log to Google Cloud
            self.logger.log_struct({
                'metric_type': 'system_health',
                'cpu_percent': cpu_percent,
                'memory_percent': memory.percent,
                'disk_percent': disk.percent,
                'timestamp': datetime.now(pytz.UTC).isoformat()
            })
            
            # Update health check status
            is_healthy = (
                cpu_percent < 90 and
                memory.percent < 90 and
                disk.percent < 90
            )
            self.health_check_status.set(1 if is_healthy else 0)
            
        except Exception as e:
            print(f"Error updating health metrics: {e}")
            self.health_check_status.set(0)
    
    def record_error(self, severity: str, category: str):
        """Record an error occurrence."""
        self.error_count.labels(severity=severity, category=category).inc()
    
    def get_system_health(self) -> Dict:
        """Get current system health metrics."""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            return {
                'cpu': {
                    'percent': cpu_percent,
                    'status': 'healthy' if cpu_percent < 90 else 'critical'
                },
                'memory': {
                    'percent': memory.percent,
                    'available_gb': memory.available / (1024**3),
                    'status': 'healthy' if memory.percent < 90 else 'critical'
                },
                'disk': {
                    'percent': disk.percent,
                    'free_gb': disk.free / (1024**3),
                    'status': 'healthy' if disk.percent < 90 else 'critical'
                },
                'timestamp': datetime.now(pytz.UTC).isoformat()
            }
        except Exception as e:
            return {'error': str(e)}

    def start_health_monitoring(self, interval: int = 60):
        """Start periodic health monitoring in a background thread."""
        def monitor():
            while True:
                self.update_health_metrics()
                time.sleep(interval)
        
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()

# Singleton instance
metrics = PerformanceMetrics()
