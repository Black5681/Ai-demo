import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import time
import logging

from core.mind_database import mind_db, Thought
from model.transformer import PX1Model, IX1Model

logger = logging.getLogger(__name__)

@dataclass
class AIContext:
    """Context for AI reasoning and decision making."""
    input_data: Any
    context_vectors: torch.Tensor
    attention_weights: Optional[torch.Tensor] = None
    confidence_score: float = 0.0
    reasoning_path: List[str] = None
    metadata: Dict[str, Any] = None

class NeuralReasoningModule(nn.Module):
    """Neural network for advanced reasoning and decision making."""
    
    def __init__(self, input_dim: int = 512, hidden_dim: int = 256, output_dim: int = 128):
        super().__init__()
        
        self.input_layer = nn.Linear(input_dim, hidden_dim)
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads=8)
        self.gru = nn.GRU(hidden_dim, hidden_dim, num_layers=2, bidirectional=True)
        self.output_layer = nn.Linear(hidden_dim * 2, output_dim)
        
        self.dropout = nn.Dropout(0.1)
        self.layer_norm = nn.LayerNorm(hidden_dim)
    
    def forward(self, x: torch.Tensor, context: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """Forward pass through the neural reasoning module."""
        # Input projection
        x = F.relu(self.input_layer(x))
        x = self.dropout(x)
        x = self.layer_norm(x)
        
        # Self-attention if no context is provided
        if context is None:
            context = x
        
        # Apply attention
        attended, attention_weights = self.attention(x, context, context)
        
        # Process with GRU
        gru_out, _ = self.gru(attended)
        
        # Output projection
        output = self.output_layer(gru_out)
        
        return output, attention_weights

class AILogicEngine:
    """Core AI logic engine for advanced reasoning and learning."""
    
    def __init__(self, model_type: str = "PX1"):
        self.model_type = model_type
        self.reasoning_module = NeuralReasoningModule()
        
        # Load appropriate transformer model
        if model_type == "PX1":
            self.transformer = PX1Model()
        elif model_type == "IX1":
            self.transformer = IX1Model()
        else:
            raise ValueError(f"Unknown model type: {model_type}")
        
        # Initialize device
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.reasoning_module.to(self.device)
        self.transformer.to(self.device)
    
    def process_input(self, input_data: Any, context: Optional[Dict[str, Any]] = None) -> AIContext:
        """Process input data through the AI logic pipeline."""
        # Convert input to tensor
        if isinstance(input_data, str):
            # Use transformer to get embeddings
            with torch.no_grad():
                input_tensor = self.transformer.encode_text(input_data)
        else:
            # Assume input is already a tensor or can be converted to one
            input_tensor = torch.tensor(input_data).float()
        
        # Move to device
        input_tensor = input_tensor.to(self.device)
        
        # Get context vectors from mind database if available
        context_vectors = []
        if context and 'query' in context:
            relevant_thoughts = mind_db.search_thoughts(context['query'], limit=5)
            for thought in relevant_thoughts:
                with torch.no_grad():
                    thought_vector = self.transformer.encode_text(thought.content)
                    context_vectors.append(thought_vector)
        
        if context_vectors:
            context_tensor = torch.stack(context_vectors).to(self.device)
        else:
            context_tensor = None
        
        # Process through reasoning module
        with torch.no_grad():
            output, attention_weights = self.reasoning_module(input_tensor, context_tensor)
        
        # Calculate confidence score
        confidence_score = float(F.softmax(output.mean(dim=0), dim=0).max().item())
        
        # Generate reasoning path
        reasoning_path = self._generate_reasoning_path(output, attention_weights)
        
        return AIContext(
            input_data=input_data,
            context_vectors=output,
            attention_weights=attention_weights,
            confidence_score=confidence_score,
            reasoning_path=reasoning_path,
            metadata={'model_type': self.model_type}
        )
    
    def _generate_reasoning_path(self, output: torch.Tensor, attention_weights: torch.Tensor) -> List[str]:
        """Generate a reasoning path based on neural network outputs."""
        reasoning_steps = []
        
        # Analyze attention patterns
        if attention_weights is not None:
            # Get the most attended positions
            top_k = 3
            _, top_indices = attention_weights.mean(dim=0).topk(top_k)
            
            for idx in top_indices:
                # Generate reasoning step based on attention position
                step = f"Focus point {idx.item()}: Attention strength {attention_weights[0, idx].item():.2f}"
                reasoning_steps.append(step)
        
        # Analyze output patterns
        output_summary = output.mean(dim=0)
        max_val, max_idx = output_summary.max(dim=0)
        reasoning_steps.append(f"Primary reasoning direction: {max_idx.item()} (strength: {max_val.item():.2f})")
        
        return reasoning_steps
    
    def evaluate_action(self, action: Any, context: AIContext) -> float:
        """Evaluate an action using the AI logic engine."""
        # Convert action to tensor representation
        if isinstance(action, str):
            with torch.no_grad():
                action_tensor = self.transformer.encode_text(action)
        else:
            action_tensor = torch.tensor(action).float()
        
        action_tensor = action_tensor.to(self.device)
        
        # Compare action with context using attention
        with torch.no_grad():
            similarity = F.cosine_similarity(
                action_tensor.mean(dim=0),
                context.context_vectors.mean(dim=0),
                dim=0
            )
        
        # Combine with confidence score
        score = float(similarity.item() * context.confidence_score)
        
        return max(0.0, min(1.0, score))  # Clamp between 0 and 1
    
    def update_from_feedback(self, feedback_score: float, context: AIContext) -> None:
        """Update the AI logic engine based on feedback."""
        # Update reasoning module weights based on feedback
        if feedback_score > 0.5:
            # Positive feedback - reinforce the attention patterns
            self._reinforce_attention_patterns(context.attention_weights)
        else:
            # Negative feedback - adjust attention patterns
            self._adjust_attention_patterns(context.attention_weights)
    
    def _reinforce_attention_patterns(self, attention_weights: torch.Tensor) -> None:
        """Reinforce successful attention patterns."""
        if attention_weights is None:
            return
        
        # Implement a simple reinforcement mechanism
        with torch.no_grad():
            # Get the attention layer from the reasoning module
            attention_layer = self.reasoning_module.attention
            
            # Update the key and value projections slightly
            if hasattr(attention_layer, 'in_proj_weight'):
                scale = 1.01  # Small positive reinforcement
                attention_layer.in_proj_weight.data *= scale
    
    def _adjust_attention_patterns(self, attention_weights: torch.Tensor) -> None:
        """Adjust attention patterns based on negative feedback."""
        if attention_weights is None:
            return
        
        # Implement a simple adjustment mechanism
        with torch.no_grad():
            # Get the attention layer from the reasoning module
            attention_layer = self.reasoning_module.attention
            
            # Update the key and value projections slightly
            if hasattr(attention_layer, 'in_proj_weight'):
                scale = 0.99  # Small negative adjustment
                attention_layer.in_proj_weight.data *= scale
    
    def save_state(self, path: str) -> None:
        """Save the AI logic engine state."""
        state = {
            'reasoning_module': self.reasoning_module.state_dict(),
            'model_type': self.model_type
        }
        torch.save(state, path)
    
    def load_state(self, path: str) -> None:
        """Load the AI logic engine state."""
        state = torch.load(path)
        self.reasoning_module.load_state_dict(state['reasoning_module'])
        self.model_type = state['model_type']

# Create singleton instance
ai_logic_engine = AILogicEngine()
