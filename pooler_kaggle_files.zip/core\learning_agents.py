import logging
import time
import random
from typing import Dict, List, Optional, Any, Tuple, Union, Set
from dataclasses import dataclass, field

from core.agent_system import CognitiveAgent, Action, Perception
from core.mind_database import mind_db, Thought
from core.thinking_engine import thinking_engine
from core.ai_logic import ai_logic_engine, AIContext

logger = logging.getLogger(__name__)

@dataclass
class LearningStrategy:
    """Defines a learning strategy for an agent."""
    name: str
    description: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    def apply(self, agent: 'LearningAgent', context: Dict[str, Any]) -> Dict[str, Any]:
        """Apply this learning strategy to the agent."""
        raise NotImplementedError("Subclasses must implement this method")

class ExploratoryLearning(LearningStrategy):
    """Learning strategy that focuses on exploring new concepts and knowledge areas."""
    
    def __init__(self, exploration_rate: float = 0.3):
        super().__init__(
            name="exploratory_learning",
            description="Explores new concepts and knowledge areas to expand understanding",
            parameters={"exploration_rate": exploration_rate}
        )
    
    def apply(self, agent: 'LearningAgent', context: Dict[str, Any]) -> Dict[str, Any]:
        # Get the exploration rate
        exploration_rate = self.parameters.get("exploration_rate", 0.3)
        
        # Decide whether to explore or exploit based on exploration rate
        if random.random() < exploration_rate:
            # Exploration: select a random knowledge gap to explore
            knowledge_gaps = agent.state.get('knowledge_gaps', [])
            if not knowledge_gaps:
                # If no knowledge gaps are identified, create some default ones
                knowledge_gaps = [
                    "quantum computing", "neural networks", "reinforcement learning",
                    "natural language processing", "computer vision"
                ]
                agent.state['knowledge_gaps'] = knowledge_gaps
            
            # Select a random knowledge gap
            selected_gap = random.choice(knowledge_gaps)
            
            # Generate a learning query based on the selected gap
            learning_query = f"Tell me about {selected_gap}"
            
            # Think about the topic
            thinking_result = agent.think(learning_query)
            
            # Store what was learned
            new_thought = Thought(
                id=None,
                content=f"Learned about {selected_gap}: {thinking_result.final_thought[:200]}...",
                category="exploratory_learning",
                importance=0.7,
                associations=[selected_gap],
                created_at=time.time(),
                last_accessed=time.time(),
                access_count=1
            )
            mind_db.store_thought(new_thought)
            
            # Update learning progress
            agent.state['learning_progress'] += 0.05
            
            return {
                "strategy": "exploration",
                "topic": selected_gap,
                "learned": thinking_result.final_thought[:100] + "...",
                "thought_id": new_thought.id
            }
        else:
            # Exploitation: use existing knowledge
            return {
                "strategy": "exploitation",
                "message": "Used existing knowledge"
            }

class PatternRecognitionLearning(LearningStrategy):
    """Learning strategy that identifies patterns in perceptions and experiences."""
    
    def __init__(self, pattern_threshold: float = 0.6):
        super().__init__(
            name="pattern_recognition",
            description="Identifies patterns in perceptions and experiences",
            parameters={"pattern_threshold": pattern_threshold}
        )
    
    def apply(self, agent: 'LearningAgent', context: Dict[str, Any]) -> Dict[str, Any]:
        # Get recent perceptions
        recent_perceptions = sorted(agent.perceptions[-10:], key=lambda p: p.timestamp)  # Last 10 perceptions
        
        if len(recent_perceptions) < 3:
            return {"strategy": "pattern_recognition", "message": "Not enough perceptions for pattern recognition"}
        
        # Extract content from perceptions
        perception_contents = [p.content for p in recent_perceptions if isinstance(p.content, str)]
        
        if not perception_contents:
            return {"strategy": "pattern_recognition", "message": "No text content in recent perceptions"}
        
        # Combine perception contents
        combined_content = " ".join(perception_contents)
        
        # Use thinking engine to identify patterns
        thinking_query = f"Identify patterns in the following content: {combined_content[:500]}"
        thinking_result = agent.think(thinking_query)
        
        # Check if the pattern recognition was successful
        if thinking_result.confidence > self.parameters.get("pattern_threshold", 0.6):
            # Store the identified pattern
            pattern_thought = Thought(
                id=None,
                content=f"Pattern identified: {thinking_result.final_thought}",
                category="pattern_recognition",
                importance=thinking_result.confidence,
                associations=["pattern", "learning"],
                created_at=time.time(),
                last_accessed=time.time(),
                access_count=1
            )
            mind_db.store_thought(pattern_thought)
            
            # Update learning progress
            agent.state['learning_progress'] += 0.1
            
            return {
                "strategy": "pattern_recognition",
                "pattern": thinking_result.final_thought,
                "confidence": thinking_result.confidence,
                "thought_id": pattern_thought.id
            }
        else:
            return {
                "strategy": "pattern_recognition",
                "message": "No significant patterns identified",
                "confidence": thinking_result.confidence
            }

class FeedbackLearning(LearningStrategy):
    """Learning strategy that learns from feedback on previous actions."""
    
    def __init__(self, feedback_weight: float = 0.8):
        super().__init__(
            name="feedback_learning",
            description="Learns from feedback on previous actions",
            parameters={"feedback_weight": feedback_weight}
        )
    
    def apply(self, agent: 'LearningAgent', context: Dict[str, Any]) -> Dict[str, Any]:
        # Get feedback from context
        feedback = context.get("feedback")
        previous_action = context.get("previous_action")
        
        if not feedback or not previous_action:
            return {"strategy": "feedback_learning", "message": "No feedback or previous action provided"}
        
        # Process feedback
        feedback_score = feedback.get("score", 0.0)
        feedback_text = feedback.get("text", "")
        
        # Store the feedback and learning
        feedback_thought = Thought(
            id=None,
            content=f"Feedback on action '{previous_action.action_type}': {feedback_text} (Score: {feedback_score})",
            category="feedback_learning",
            importance=0.8,  # Feedback is important
            associations=[previous_action.action_type, "feedback"],
            created_at=time.time(),
            last_accessed=time.time(),
            access_count=1
        )
        mind_db.store_thought(feedback_thought)
        
        # Update action weights based on feedback
        action_type = previous_action.action_type
        current_weight = agent.action_weights.get(action_type, 1.0)
        feedback_weight = self.parameters.get("feedback_weight", 0.8)
        
        # Adjust weight based on feedback score
        new_weight = (current_weight * (1 - feedback_weight)) + (feedback_score * feedback_weight)
        agent.action_weights[action_type] = max(0.1, min(2.0, new_weight))  # Keep weight in reasonable range
        
        # Update learning progress
        agent.state['learning_progress'] += 0.05
        
        return {
            "strategy": "feedback_learning",
            "action_type": action_type,
            "previous_weight": current_weight,
            "new_weight": agent.action_weights[action_type],
            "feedback_score": feedback_score,
            "thought_id": feedback_thought.id
        }

class LearningAgent(CognitiveAgent):
    """An agent specializing in learning from experiences and improving over time."""
    
    def __init__(self, agent_id: str, model_type: str = "PX1"):
        super().__init__(agent_id, model_type)
        
        # Initialize learning-specific state
        self.learning_strategies: Dict[str, LearningStrategy] = {
            "exploratory": ExploratoryLearning(),
            "pattern_recognition": PatternRecognitionLearning(),
            "feedback": FeedbackLearning()
        }
        
        self.active_strategy: Optional[str] = None
        self.action_weights: Dict[str, float] = {}
        self.learned_concepts: Set[str] = set()
        
        # Initialize AI context
        self.current_context: Optional[AIContext] = None
        
        # Update agent state
        self.state.update({
            'learning_rate': 0.1,
            'knowledge_gaps': [],
            'learning_history': [],
            'ai_confidence_threshold': 0.7
        })
    
    def think(self, query: str, context: Optional[str] = None) -> Any:
        """Enhanced thinking process with AI logic."""
        # First, use the standard thinking process
        thinking_result = super().think(query, context)
        
        # Process through AI logic engine
        ai_context = ai_logic_engine.process_input(
            query,
            context={'query': query, 'thinking_result': thinking_result}
        )
        
        # Store the AI context
        self.current_context = ai_context
        
        # If AI confidence is high enough, enhance the thinking result
        if ai_context.confidence_score >= self.state['ai_confidence_threshold']:
            # Combine standard thinking with AI reasoning
            enhanced_thought = f"{thinking_result.final_thought}\n\nAI Reasoning Path:\n"
            enhanced_thought += "\n".join(ai_context.reasoning_path)
            
            thinking_result.final_thought = enhanced_thought
            thinking_result.confidence = max(
                thinking_result.confidence,
                ai_context.confidence_score
            )
        
        return thinking_result
    
    def generate_actions(self) -> List[Action]:
        """Generate actions with AI-enhanced decision making."""
        # Get standard actions
        actions = super().generate_actions()
        
        # Add learning-specific actions
        learning_actions = [
            Action(
                action_type="learn",
                parameters={
                    "strategy": "exploratory",
                    "context": {}
                },
                priority=0.6
            ),
            Action(
                action_type="learn",
                parameters={
                    "strategy": "pattern_recognition",
                    "context": {}
                },
                priority=0.5
            )
        ]
        
        actions.extend(learning_actions)
        
        # If we have an AI context, use it to evaluate and adjust action priorities
        if self.current_context:
            for action in actions:
                # Evaluate action using AI logic
                ai_score = ai_logic_engine.evaluate_action(
                    action.action_type,
                    self.current_context
                )
                
                # Combine AI score with existing priority
                action.priority = (action.priority + ai_score) / 2
                
                # Apply learned weights
                if action.action_type in self.action_weights:
                    action.priority *= self.action_weights[action.action_type]
        
        return sorted(actions, key=lambda x: x.priority, reverse=True)
    
    def execute_action(self, action: Action) -> Dict[str, Any]:
        """Execute action with AI monitoring and learning."""
        # Execute the action
        result = super().execute_action(action)
        
        # Record the action in history
        if 'action_history' not in self.state:
            self.state['action_history'] = []
        self.state['action_history'].append(action)
        
        # Limit history size
        if len(self.state['action_history']) > 100:
            self.state['action_history'] = self.state['action_history'][-100:]
        
        # If we have an AI context, update based on the result
        if self.current_context and 'success' in result:
            # Use success as a basic form of feedback
            feedback_score = 1.0 if result['success'] else 0.0
            ai_logic_engine.update_from_feedback(feedback_score, self.current_context)
        
        return result
    
    def learn(self, strategy_name: Optional[str] = None, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Enhanced learning process with AI logic."""
        if context is None:
            context = {}
        
        # Select strategy
        if strategy_name is None:
            # Use AI to select the best strategy if we have a current context
            if self.current_context and self.current_context.confidence_score > 0.5:
                # Evaluate each strategy
                strategy_scores = {
                    name: ai_logic_engine.evaluate_action(name, self.current_context)
                    for name in self.learning_strategies.keys()
                }
                strategy_name = max(strategy_scores.items(), key=lambda x: x[1])[0]
            else:
                # Fall back to random selection
                strategy_name = random.choice(list(self.learning_strategies.keys()))
        
        # Apply the strategy
        self.active_strategy = strategy_name
        strategy = self.learning_strategies[strategy_name]
        result = strategy.apply(self, context)
        
        # Record the learning
        learning_entry = {
            "strategy": strategy_name,
            "timestamp": time.time(),
            "result": result,
            "ai_confidence": self.current_context.confidence_score if self.current_context else None
        }
        self.state['learning_history'].append(learning_entry)
        
        # Limit history size
        if len(self.state['learning_history']) > 100:
            self.state['learning_history'] = self.state['learning_history'][-100:]
        
        return result
    
    def provide_feedback(self, action: Action, score: float, text: str = "") -> Dict[str, Any]:
        """Process feedback with AI-enhanced learning."""
        feedback = {"score": score, "text": text}
        context = {"feedback": feedback, "previous_action": action}
        
        # Learn from the feedback using the feedback strategy
        result = self.learn("feedback", context)
        
        # If we have an AI context, update it based on the feedback
        if self.current_context:
            ai_logic_engine.update_from_feedback(score, self.current_context)
        
        return result
    
    def save_state(self, path: str) -> None:
        """Save agent state including AI components."""
        super().save_state(path)
        ai_logic_engine.save_state(f"{path}_ai")
    
    def load_state(self, path: str) -> None:
        """Load agent state including AI components."""
        super().load_state(path)
        ai_logic_engine.load_state(f"{path}_ai")

# Factory function to create a learning agent
def create_learning_agent(agent_id: str, model_type: str = "PX1") -> LearningAgent:
    """Create and initialize a new learning agent."""
    agent = LearningAgent(agent_id, model_type)
    logger.info(f"Created new learning agent with ID: {agent_id}, model type: {model_type}")
    return agent
