import logging
import traceback
from enum import Enum
from typing import Dict, Optional, Any, Tuple
from pydantic import BaseModel
from google.cloud import logging as gcp_logging
import json
import time
from logging.handlers import RotatingFileHandler
import psutil
import torch

class ErrorSeverity(str, Enum):
    CRITICAL = "critical"  # System cannot function
    ERROR = "error"        # Operation failed but system still functional
    WARNING = "warning"    # Potential issue that doesn't affect operation
    INFO = "info"          # Informational message about non-critical issues

class ErrorCategory(str, Enum):
    MODEL_LOADING = "model_loading"  # Issues with loading AI models
    INFERENCE = "inference"          # Issues during model inference
    API = "api"                      # API-related errors
    AUTHENTICATION = "authentication" # Auth issues
    DATABASE = "database"            # Database connection/query issues
    RESOURCE = "resource"            # Resource constraints (memory, CPU)
    NETWORK = "network"              # Network connectivity issues
    VALIDATION = "validation"        # Input validation errors
    UNKNOWN = "unknown"              # Uncategorized errors

class ErrorResponse(BaseModel):
    error_code: str
    message: str
    details: Optional[str] = None
    severity: ErrorSeverity
    category: ErrorCategory
    timestamp: float
    request_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "error": {
                "code": self.error_code,
                "message": self.message,
                "details": self.details,
                "severity": self.severity,
                "category": self.category,
                "timestamp": self.timestamp,
                "request_id": self.request_id
            }
        }

class ErrorHandler:
    def __init__(self, project_id: str = "pooler-ai-project", use_cloud_logging: bool = True):
        # Set up standard logging
        self.logger = logging.getLogger("pooler_ai")
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
            
            # Also log to file with rotation
            file_handler = RotatingFileHandler(
                "pooler_ai_errors.log",
                maxBytes=10*1024*1024,  # 10MB
                backupCount=5
            )
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
        
        # Set up Google Cloud Logging if enabled
        self.use_cloud_logging = use_cloud_logging
        if use_cloud_logging:
            try:
                self.cloud_logger = gcp_logging.Client(project=project_id).logger("pooler_ai_errors")
            except Exception as e:
                self.logger.warning(f"Failed to initialize Google Cloud Logging: {e}")
                self.use_cloud_logging = False
        
        # Error code mapping for user-friendly messages
        self.error_messages = {
            # Model errors
            "MODEL_NOT_FOUND": "The requested AI model could not be found.",
            "MODEL_LOADING_FAILED": "Failed to load the AI model. Please try again later.",
            "INFERENCE_TIMEOUT": "The model took too long to respond. Please try again with a simpler request.",
            "INFERENCE_ERROR": "An error occurred while processing your request.",
            "OUT_OF_MEMORY": "The system is currently experiencing high demand. Please try again later.",
            
            # API errors
            "INVALID_REQUEST": "Your request was invalid. Please check the input parameters.",
            "RATE_LIMIT_EXCEEDED": "You have exceeded the rate limit. Please try again later.",
            "UNAUTHORIZED": "You are not authorized to perform this action.",
            "INSTANCE_NOT_FOUND": "The requested AI instance could not be found.",
            "SERVICE_UNAVAILABLE": "The service is temporarily unavailable. Please try again later.",
            
            # Generic errors
            "INTERNAL_ERROR": "An internal error occurred. Our team has been notified.",
            "UNKNOWN_ERROR": "An unexpected error occurred. Please try again later."
        }
    
    def handle_error(self, 
                    error_code: str, 
                    exception: Optional[Exception] = None, 
                    details: Optional[str] = None,
                    severity: ErrorSeverity = ErrorSeverity.ERROR,
                    category: ErrorCategory = ErrorCategory.UNKNOWN,
                    request_id: Optional[str] = None) -> ErrorResponse:
        """Handle an error and return a standardized error response."""
        # Get user-friendly message or use the error code as fallback
        message = self.error_messages.get(error_code, f"Error: {error_code}")
        
        # Get exception details if provided
        if exception and not details:
            details = str(exception)
        
        # Create error response
        error_response = ErrorResponse(
            error_code=error_code,
            message=message,
            details=details,
            severity=severity,
            category=category,
            timestamp=time.time(),
            request_id=request_id
        )
        
        # Log the error
        self._log_error(error_response, exception)
        
        return error_response
    
    def _log_error(self, error: ErrorResponse, exception: Optional[Exception] = None):
        """Log the error to appropriate channels."""
        # Determine log level
        log_level = {
            ErrorSeverity.CRITICAL: logging.CRITICAL,
            ErrorSeverity.ERROR: logging.ERROR,
            ErrorSeverity.WARNING: logging.WARNING,
            ErrorSeverity.INFO: logging.INFO
        }.get(error.severity, logging.ERROR)
        
        # Create log message
        log_message = f"{error.error_code}: {error.message}"
        if error.details:
            log_message += f" - {error.details}"
        
        # Add exception traceback if available
        if exception:
            log_message += f"\n{traceback.format_exc()}"
        
        # Add system health info for critical errors
        if error.severity == ErrorSeverity.CRITICAL:
            health_info = self._get_system_health()
            log_message += f"\nSystem Health at time of error: {json.dumps(health_info, indent=2)}"
        
        # Log to standard logger
        self.logger.log(log_level, log_message)
        
        # Log to Google Cloud if enabled
        if self.use_cloud_logging:
            try:
                self.cloud_logger.log_struct(
                    {
                        "error_code": error.error_code,
                        "message": error.message,
                        "details": error.details,
                        "severity": error.severity,
                        "category": error.category,
                        "request_id": error.request_id,
                        "traceback": traceback.format_exc() if exception else None,
                        "system_health": self._get_system_health() if error.severity == ErrorSeverity.CRITICAL else None
                    },
                    severity=error.severity.upper()
                )
            except Exception as e:
                self.logger.error(f"Failed to log to Google Cloud: {e}")

    def _get_system_health(self) -> Dict[str, Any]:
        """Get current system health metrics."""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            health_info = {
                "cpu_percent": cpu_percent,
                "memory_percent": memory.percent,
                "memory_available_gb": memory.available / (1024**3),
                "disk_percent": disk.percent,
                "disk_free_gb": disk.free / (1024**3),
                "gpu_available": torch.cuda.is_available() if hasattr(torch, 'cuda') else False,
                "gpu_memory_allocated": None
            }
            
            if health_info["gpu_available"]:
                health_info["gpu_memory_allocated"] = torch.cuda.memory_allocated() / (1024**3)
            
            return health_info
        except Exception as e:
            return {"error": f"Failed to get system health: {str(e)}"}

    def check_system_health(self) -> Tuple[bool, Dict[str, Any]]:
        """Check if the system is healthy based on resource thresholds."""
        health_info = self._get_system_health()
        
        # Define thresholds
        thresholds = {
            "cpu_percent": 90,
            "memory_percent": 90,
            "disk_percent": 90,
            "min_memory_gb": 2,
            "min_disk_gb": 5
        }
        
        # Check against thresholds
        is_healthy = True
        if "error" not in health_info:
            if health_info["cpu_percent"] > thresholds["cpu_percent"]:
                is_healthy = False
            if health_info["memory_percent"] > thresholds["memory_percent"]:
                is_healthy = False
            if health_info["memory_available_gb"] < thresholds["min_memory_gb"]:
                is_healthy = False
            if health_info["disk_percent"] > thresholds["disk_percent"]:
                is_healthy = False
            if health_info["disk_free_gb"] < thresholds["min_disk_gb"]:
                is_healthy = False
        else:
            is_healthy = False
        
        return is_healthy, health_info

    def graceful_degradation(self, error_code: str, fallback_function: callable, *args, **kwargs) -> Tuple[Any, bool]:
        """Attempt to gracefully degrade by using a fallback function.
        
        Returns:
            Tuple containing (result, is_fallback)
            - result: The result from either the original function or fallback
            - is_fallback: True if the fallback was used, False otherwise
        """
        try:
            # Log that we're attempting graceful degradation
            self.logger.info(f"Attempting graceful degradation for {error_code}")
            
            # Call the fallback function
            result = fallback_function(*args, **kwargs)
            
            # Log success
            self.logger.info(f"Graceful degradation successful for {error_code}")
            
            return result, True
        except Exception as e:
            # Log that even the fallback failed
            self.logger.error(f"Fallback for {error_code} also failed: {e}")
            raise e

# Create a singleton instance
error_handler = ErrorHandler()
