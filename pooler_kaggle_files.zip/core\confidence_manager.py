import torch
from typing import Dict, Any, Optional
from dataclasses import dataclass

@dataclass
class ConfidenceMetrics:
    base_confidence: float
    depth_bonus: float
    context_multiplier: float
    emotional_factor: float

class ConfidenceManager:
    def __init__(self):
        # Initialize confidence thresholds from memory
        self.confidence_levels = {
            "initial": 0.4,  # Initial thoughts
            "intermediate": 0.6,  # Relationship analysis
            "mature": 0.8,  # Deep reasoning
            "termination": 0.7,  # When to stop thinking
            "storage": 0.6  # When to store in mind_db
        }
        
        self.depth_bonus = 0.1  # Confidence increase per depth level
        
    def calculate_confidence(self, 
                           thought_type: str,
                           depth: int,
                           context_strength: float = 0.0,
                           emotional_resonance: float = 0.0) -> float:
        """Calculate confidence score for a thought."""
        # Base confidence from thought type
        base = self.confidence_levels.get(thought_type, self.confidence_levels["initial"])
        
        # Add depth bonus (capped)
        depth_bonus = min(self.depth_bonus * depth, 
                         self.confidence_levels["mature"] - base)
        
        # Context influence
        context_multiplier = 1.0 + (context_strength * 0.2)
        
        # Emotional factor
        emotional_factor = 1.0 + (emotional_resonance * 0.1)
        
        # Calculate final confidence
        confidence = base + depth_bonus
        confidence *= context_multiplier
        confidence *= emotional_factor
        
        # Cap at mature thought level
        return min(confidence, self.confidence_levels["mature"])
    
    def should_terminate(self, current_confidence: float) -> bool:
        """Check if thinking should terminate."""
        return current_confidence >= self.confidence_levels["termination"]
    
    def should_store(self, confidence: float) -> bool:
        """Check if thought should be stored in mind_db."""
        return confidence >= self.confidence_levels["storage"]
    
    def get_metrics(self, 
                   thought_type: str,
                   depth: int,
                   context_strength: float,
                   emotional_resonance: float) -> ConfidenceMetrics:
        """Get detailed confidence metrics."""
        base = self.confidence_levels.get(thought_type, self.confidence_levels["initial"])
        depth_bonus = min(self.depth_bonus * depth,
                         self.confidence_levels["mature"] - base)
        context_mult = 1.0 + (context_strength * 0.2)
        emotional_fact = 1.0 + (emotional_resonance * 0.1)
        
        return ConfidenceMetrics(
            base_confidence=base,
            depth_bonus=depth_bonus,
            context_multiplier=context_mult,
            emotional_factor=emotional_fact
        )
    
    def analyze_confidence_chain(self, 
                               thought_chain: list,
                               min_confidence: Optional[float] = None) -> Dict[str, Any]:
        """Analyze confidence progression in a thought chain."""
        if not thought_chain:
            return {"status": "empty", "confidence_trend": 0.0}
        
        confidences = [t.get("confidence", 0.0) for t in thought_chain]
        min_conf = min_confidence or self.confidence_levels["initial"]
        
        return {
            "status": "valid" if all(c >= min_conf for c in confidences) else "low_confidence",
            "confidence_trend": sum(y - x for x, y in zip(confidences, confidences[1:])) / (len(confidences) - 1),
            "min_confidence": min(confidences),
            "max_confidence": max(confidences),
            "avg_confidence": sum(confidences) / len(confidences)
        }
    
    def adjust_thresholds(self, 
                         performance_metrics: Dict[str, float],
                         learning_rate: float = 0.1):
        """Dynamically adjust confidence thresholds based on performance."""
        if "accuracy" in performance_metrics:
            # Adjust termination threshold
            accuracy = performance_metrics["accuracy"]
            if accuracy > 0.9:
                # System is being too conservative, lower threshold
                self.confidence_levels["termination"] = max(
                    0.6,
                    self.confidence_levels["termination"] - learning_rate
                )
            elif accuracy < 0.7:
                # System is being too aggressive, raise threshold
                self.confidence_levels["termination"] = min(
                    0.9,
                    self.confidence_levels["termination"] + learning_rate
                )
        
        if "storage_efficiency" in performance_metrics:
            # Adjust storage threshold
            efficiency = performance_metrics["storage_efficiency"]
            if efficiency < 0.5:
                # Too much irrelevant storage, raise threshold
                self.confidence_levels["storage"] = min(
                    0.8,
                    self.confidence_levels["storage"] + learning_rate
                )
            elif efficiency > 0.9:
                # Missing useful information, lower threshold
                self.confidence_levels["storage"] = max(
                    0.5,
                    self.confidence_levels["storage"] - learning_rate
                )
