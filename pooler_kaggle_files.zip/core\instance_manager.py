from typing import Dict, Optional
import asyncio
import redis
from pydantic import BaseModel
import json
import time
from uuid import uuid4

class EmotionalState(BaseModel):
    valence: float  # -1 (negative) to 1 (positive)
    arousal: float  # 0 (calm) to 1 (excited)
    dominance: float  # 0 (submissive) to 1 (dominant)

class Personality(BaseModel):
    openness: float
    conscientiousness: float
    extraversion: float
    agreeableness: float
    neuroticism: float
    
    @classmethod
    def default(cls):
        return cls(
            openness=0.7,
            conscientiousness=0.8,
            extraversion=0.6,
            agreeableness=0.75,
            neuroticism=0.3
        )

class AIInstance(BaseModel):
    instance_id: str
    personality: Personality
    emotional_state: EmotionalState
    last_active: float
    model_type: str  # 'PX1' or 'IX1'
    busy: bool = False

class InstanceManager:
    def __init__(self, redis_url: str = "redis://localhost:6379"):
        self.redis_client = redis.Redis.from_url(redis_url, decode_responses=True)
        self.instances: Dict[str, AIInstance] = {}
        self.max_instances = 10
        self.instance_timeout = 300  # 5 minutes

    async def create_instance(self, model_type: str, personality: Optional[Personality] = None) -> AIInstance:
        # Clean up inactive instances first
        self._cleanup_inactive_instances()
        
        if len(self.instances) >= self.max_instances:
            # Try to find an inactive instance to replace
            for inst_id, instance in self.instances.items():
                if time.time() - instance.last_active > self.instance_timeout:
                    await self.remove_instance(inst_id)
                    break
            else:
                raise Exception("Maximum number of instances reached")

        instance_id = str(uuid4())
        instance = AIInstance(
            instance_id=instance_id,
            personality=personality or Personality.default(),
            emotional_state=EmotionalState(valence=0.0, arousal=0.5, dominance=0.5),
            last_active=time.time(),
            model_type=model_type
        )
        
        self.instances[instance_id] = instance
        self._save_instance(instance)
        return instance

    def get_instance(self, instance_id: str) -> Optional[AIInstance]:
        if instance_id in self.instances:
            instance = self.instances[instance_id]
            instance.last_active = time.time()
            self._save_instance(instance)
            return instance
        return None

    async def update_emotional_state(self, instance_id: str, new_state: EmotionalState):
        if instance_id in self.instances:
            instance = self.instances[instance_id]
            instance.emotional_state = new_state
            instance.last_active = time.time()
            self._save_instance(instance)

    def _save_instance(self, instance: AIInstance):
        self.redis_client.hset(
            f"instance:{instance.instance_id}",
            mapping={
                "data": instance.json(),
                "last_active": str(instance.last_active)
            }
        )

    def _cleanup_inactive_instances(self):
        current_time = time.time()
        inactive_instances = [
            inst_id for inst_id, inst in self.instances.items()
            if current_time - inst.last_active > self.instance_timeout
        ]
        for inst_id in inactive_instances:
            asyncio.create_task(self.remove_instance(inst_id))

    async def remove_instance(self, instance_id: str):
        if instance_id in self.instances:
            del self.instances[instance_id]
            self.redis_client.delete(f"instance:{instance_id}")

    def get_available_instance(self, model_type: str) -> Optional[AIInstance]:
        available_instances = [
            inst for inst in self.instances.values()
            if inst.model_type == model_type and not inst.busy
        ]
        if not available_instances:
            return None
        # Return the instance with the longest idle time
        return min(available_instances, key=lambda x: x.last_active)

    async def mark_instance_busy(self, instance_id: str, busy: bool = True):
        if instance_id in self.instances:
            self.instances[instance_id].busy = busy
            self._save_instance(self.instances[instance_id])
