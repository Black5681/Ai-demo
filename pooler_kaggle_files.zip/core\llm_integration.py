"""
Pooler AI - LLM Integration with BillyDoc
=========================================

This module integrates the custom LLM implementations (PX1 and IX1)
with BillyDoc's error handling system to provide advanced error analysis,
diagnosis, and fixing capabilities.
"""

import torch
import logging
import threading
from typing import Dict, List, Optional, Tuple, Any, Union
from datetime import datetime

# Import the custom LLM models
from model.llm import PX1LLM, IX1LLM

# Import BillyDoc for error handling integration
from core.billy_doc import BillyDoc

logger = logging.getLogger(__name__)

class LLMErrorAnalyzer:
    """
    Integrates PX1 LLM with BillyDoc for advanced error analysis.
    Uses the language understanding capabilities of PX1 to enhance
    error diagnosis and generate more accurate fixes.
    """
    
    def __init__(self, billy_doc: BillyDoc, model_path: Optional[str] = None):
        """
        Initialize the LLM Error Analyzer.
        
        Args:
            billy_doc: Instance of BillyDoc for error handling
            model_path: Optional path to pre-trained model weights
        """
        self.billy_doc = billy_doc
        
        # Initialize a smaller version of PX1 for error analysis
        self.model = PX1LLM(
            vocab_size=10000,
            d_model=1024,
            num_heads=16,
            num_layers=12,
            d_ff=4096
        )
        
        # Load pre-trained weights if provided
        if model_path:
            try:
                self.model.load_state_dict(torch.load(model_path))
                logger.info(f"Loaded LLM model from {model_path}")
            except Exception as e:
                logger.warning(f"Failed to load model from {model_path}: {e}")
                logger.info("Using initialized model without pre-trained weights")
        
        # Set confidence thresholds aligned with BillyDoc's system
        self.confidence_thresholds = {
            "analysis": 0.6,  # Threshold for error analysis
            "fix": 0.7,       # Threshold for fix generation
            "validation": 0.8  # Threshold for fix validation
        }
        
        # Error type to processor mapping
        self.error_processors = {
            "SyntaxError": "code",
            "IndentationError": "code",
            "ImportError": "code",
            "AttributeError": "code",
            "TypeError": "code",
            "NameError": "code",
            "ValueError": "math",
            "IndexError": "math",
            "KeyError": "math",
            "MemoryError": "science",
            "OverflowError": "science",
            "RuntimeError": "science",
            "RecursionError": "science",
            "ConcurrentError": "science"
        }
        
        logger.info("LLM Error Analyzer initialized")
    
    def analyze_error(self, error: Exception, code_context: str) -> Dict[str, Any]:
        """
        Analyze an error using the PX1 LLM.
        
        Args:
            error: The exception to analyze
            code_context: The code context where the error occurred
            
        Returns:
            Analysis results including confidence score and potential fixes
        """
        # Determine error type and select appropriate processor
        error_type = type(error).__name__
        processor_type = self.error_processors.get(error_type, "code")
        
        # Convert error and context to token IDs (simplified for demonstration)
        # In a real implementation, this would use a proper tokenizer
        error_tokens = torch.randint(0, 10000, (1, 100))
        
        # Process through the LLM
        with torch.no_grad():
            features = self.model(error_tokens, processor_type=processor_type)
        
        # Calculate confidence score (simplified)
        confidence_score = 0.6 + torch.sigmoid(features[0, 0, 0]).item() * 0.3
        
        # Prepare analysis results
        analysis = {
            "error_type": error_type,
            "timestamp": datetime.now().isoformat(),
            "confidence": confidence_score,
            "processor_used": processor_type,
            "potential_fixes": [],
            "root_cause": None,
            "severity": self._assess_severity(error, confidence_score)
        }
        
        # Generate potential fixes if confidence is high enough
        if confidence_score >= self.confidence_thresholds["analysis"]:
            analysis["potential_fixes"] = self._generate_fixes(error, code_context, processor_type)
            analysis["root_cause"] = self._identify_root_cause(error, code_context, processor_type)
        
        logger.info(f"Analyzed {error_type} with confidence {confidence_score:.2f}")
        return analysis
    
    def _generate_fixes(self, error: Exception, code_context: str, processor_type: str) -> List[Dict[str, Any]]:
        """Generate potential fixes for the error."""
        # In a real implementation, this would use the LLM to generate fixes
        # Here we're providing a simplified version
        fixes = []
        
        # Basic fix generation based on error type
        error_type = type(error).__name__
        if error_type == "SyntaxError":
            fixes.append({
                "description": "Fix syntax error by adding missing parenthesis/bracket",
                "confidence": 0.75,
                "code_change": "# Add missing closing parenthesis\n# or bracket"
            })
        elif error_type == "ImportError":
            fixes.append({
                "description": "Install missing module or fix import path",
                "confidence": 0.8,
                "code_change": "# pip install missing_module\n# or correct import path"
            })
        elif error_type == "AttributeError":
            fixes.append({
                "description": "Fix attribute reference or check object type",
                "confidence": 0.7,
                "code_change": "# Check if object has the attribute\n# or use hasattr() first"
            })
        else:
            fixes.append({
                "description": f"Generic fix for {error_type}",
                "confidence": 0.6,
                "code_change": f"# Fix for {error_type}\n# Specific code would be generated by LLM"
            })
        
        return fixes
    
    def _identify_root_cause(self, error: Exception, code_context: str, processor_type: str) -> Dict[str, Any]:
        """Identify the root cause of the error."""
        # In a real implementation, this would use the LLM to identify root causes
        # Here we're providing a simplified version
        return {
            "type": type(error).__name__,
            "message": str(error),
            "confidence": 0.75,
            "location": "Unknown",  # Would be determined by analysis
            "description": f"Root cause analysis for {type(error).__name__}"
        }
    
    def _assess_severity(self, error: Exception, confidence: float) -> str:
        """Assess the severity of the error."""
        error_type = type(error).__name__
        
        # Critical errors that could crash the system
        if error_type in ["MemoryError", "SystemError", "RecursionError"]:
            return "critical"
        
        # High severity errors that affect functionality
        if error_type in ["ImportError", "ModuleNotFoundError", "SyntaxError"]:
            return "high"
        
        # Medium severity errors that may be recoverable
        if error_type in ["AttributeError", "TypeError", "ValueError"]:
            return "medium"
        
        # Low severity errors that are easily fixable
        return "low"
    
    def validate_fix(self, fix: Dict[str, Any], error: Exception, code_context: str) -> float:
        """
        Validate a proposed fix using the LLM.
        
        Args:
            fix: The proposed fix
            error: The original error
            code_context: The code context
            
        Returns:
            Confidence score for the fix (0.0 to 1.0)
        """
        # In a real implementation, this would use the LLM to validate the fix
        # Here we're providing a simplified version
        processor_type = self.error_processors.get(type(error).__name__, "code")
        
        # Convert inputs to token IDs (simplified)
        tokens = torch.randint(0, 10000, (1, 100))
        
        # Process through the LLM
        with torch.no_grad():
            features = self.model(tokens, processor_type=processor_type)
        
        # Calculate validation score (simplified)
        validation_score = 0.5 + torch.sigmoid(features[0, 0, 0]).item() * 0.4
        
        logger.info(f"Validated fix with confidence {validation_score:.2f}")
        return validation_score

class LLMErrorHandler:
    """
    Main class for integrating LLM capabilities with BillyDoc's error handling.
    Provides a high-level interface for using LLM-powered error analysis,
    diagnosis, and fixing.
    """
    
    def __init__(self, project_root: str, model_path: Optional[str] = None):
        """
        Initialize the LLM Error Handler.
        
        Args:
            project_root: Root directory of the project
            model_path: Optional path to pre-trained model weights
        """
        # Initialize BillyDoc
        self.billy_doc = BillyDoc(project_root)
        
        # Initialize LLM Error Analyzer
        self.analyzer = LLMErrorAnalyzer(self.billy_doc, model_path)
        
        # Thread lock for concurrent error handling
        self.lock = threading.Lock()
        
        # Error history for tracking concurrent errors
        self.error_history = []
        
        logger.info("LLM Error Handler initialized")
    
    def handle_error(self, error: Exception, code_context: str = "") -> Dict[str, Any]:
        """
        Handle an error using LLM-powered analysis and BillyDoc's fixing capabilities.
        
        Args:
            error: The exception to handle
            code_context: The code context where the error occurred
            
        Returns:
            Results of error handling including analysis and fixes
        """
        with self.lock:
            # First, let BillyDoc diagnose the error
            self.billy_doc.diagnose_error(error)
            
            # Then, enhance the diagnosis with LLM analysis
            analysis = self.analyzer.analyze_error(error, code_context)
            
            # Add to error history for concurrent error detection
            self.error_history.append({
                "error": error,
                "analysis": analysis,
                "timestamp": datetime.now()
            })
            
            # Trim history to keep only recent errors (last 5 minutes)
            self._trim_error_history()
            
            # Check for concurrent errors
            concurrent_errors = self._detect_concurrent_errors()
            
            # Handle concurrent errors if detected
            if concurrent_errors:
                logger.warning(f"Detected {len(concurrent_errors)} concurrent errors")
                for error_group in concurrent_errors:
                    self.billy_doc.fix_concurrent_errors(error_group)
            
            # Generate and validate fixes
            fixes = []
            for potential_fix in analysis["potential_fixes"]:
                validation_score = self.analyzer.validate_fix(potential_fix, error, code_context)
                
                if validation_score >= self.analyzer.confidence_thresholds["validation"]:
                    # High confidence fix - apply directly
                    fixes.append({
                        **potential_fix,
                        "validation_score": validation_score,
                        "status": "applied"
                    })
                elif validation_score >= self.analyzer.confidence_thresholds["fix"]:
                    # Medium confidence fix - suggest but don't apply
                    fixes.append({
                        **potential_fix,
                        "validation_score": validation_score,
                        "status": "suggested"
                    })
                else:
                    # Low confidence fix - log but don't suggest
                    fixes.append({
                        **potential_fix,
                        "validation_score": validation_score,
                        "status": "low_confidence"
                    })
            
            # Check system health
            health_report = self.billy_doc.check_system_health()
            
            return {
                "error": str(error),
                "error_type": type(error).__name__,
                "analysis": analysis,
                "fixes": fixes,
                "concurrent_errors": concurrent_errors,
                "system_health": health_report["status"],
                "timestamp": datetime.now().isoformat()
            }
    
    def _trim_error_history(self):
        """Trim error history to keep only recent errors (last 5 minutes)."""
        current_time = datetime.now()
        self.error_history = [
            entry for entry in self.error_history
            if (current_time - datetime.fromisoformat(entry["analysis"]["timestamp"])).total_seconds() < 300
        ]
    
    def _detect_concurrent_errors(self) -> List[Dict[str, Any]]:
        """Detect concurrent errors in the error history."""
        # Group errors by time proximity (within 5 seconds)
        error_groups = []
        processed_indices = set()
        
        for i, entry in enumerate(self.error_history):
            if i in processed_indices:
                continue
            
            current_time = datetime.fromisoformat(entry["analysis"]["timestamp"])
            group = [entry]
            processed_indices.add(i)
            
            for j, other_entry in enumerate(self.error_history):
                if j in processed_indices or j == i:
                    continue
                
                other_time = datetime.fromisoformat(other_entry["analysis"]["timestamp"])
                if abs((current_time - other_time).total_seconds()) <= 5:
                    group.append(other_entry)
                    processed_indices.add(j)
            
            if len(group) > 1:
                # Format the error group for BillyDoc
                error_types = {entry["analysis"]["error_type"] for entry in group}
                severities = {entry["analysis"]["severity"] for entry in group}
                
                # Find the highest severity
                severity_rank = {"critical": 3, "high": 2, "medium": 1, "low": 0}
                highest_severity = max(severities, key=lambda s: severity_rank.get(s, 0))
                
                # Identify potential root cause (highest confidence analysis)
                root_cause = max(group, key=lambda e: e["analysis"]["confidence"])["analysis"]
                
                error_group = {
                    "error_types": list(error_types),
                    "severity": highest_severity,
                    "timestamp": current_time.isoformat(),
                    "errors": [str(entry["error"]) for entry in group],
                    "root_cause": root_cause["root_cause"],
                    "cascade_pattern": self._detect_cascade_pattern(group)
                }
                
                error_groups.append(error_group)
        
        return error_groups
    
    def _detect_cascade_pattern(self, error_group: List[Dict[str, Any]]) -> str:
        """Detect if errors follow a cascade pattern."""
        # Sort errors by timestamp
        sorted_errors = sorted(
            error_group, 
            key=lambda e: datetime.fromisoformat(e["analysis"]["timestamp"])
        )
        
        # Check time intervals between errors
        intervals = []
        for i in range(1, len(sorted_errors)):
            prev_time = datetime.fromisoformat(sorted_errors[i-1]["analysis"]["timestamp"])
            curr_time = datetime.fromisoformat(sorted_errors[i]["analysis"]["timestamp"])
            intervals.append((curr_time - prev_time).total_seconds())
        
        # No intervals for a single error
        if not intervals:
            return "single_error"
        
        # Check if intervals are decreasing (accelerating cascade)
        if all(intervals[i] > intervals[i+1] for i in range(len(intervals)-1)):
            return "accelerating_cascade"
        
        # Check if intervals are very small (rapid cascade)
        if all(interval < 0.5 for interval in intervals):
            return "rapid_cascade"
        
        # Check if intervals are increasing (decelerating cascade)
        if all(intervals[i] < intervals[i+1] for i in range(len(intervals)-1)):
            return "decelerating_cascade"
        
        # Default pattern
        return "irregular_cascade"

# Initialize the LLM Error Handler
def initialize_llm_error_handler(project_root: str, model_path: Optional[str] = None) -> LLMErrorHandler:
    """
    Initialize and return an LLM Error Handler instance.
    
    Args:
        project_root: Root directory of the project
        model_path: Optional path to pre-trained model weights
        
    Returns:
        Initialized LLM Error Handler
    """
    handler = LLMErrorHandler(project_root, model_path)
    logger.info(f"Initialized LLM Error Handler for project: {project_root}")
    return handler
