import torch
import torch.nn as nn
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import asyncio

@dataclass
class AgentMessage:
    sender_id: str
    receiver_id: str
    content: Any
    priority: float
    timestamp: float

class MultiAgentSystem:
    def __init__(self, num_agents: int = 3):
        self.agents = {}
        self.message_queue = asyncio.Queue()
        self.shared_knowledge = SharedKnowledge()
        self.coordinator = TaskCoordinator()
        
    async def register_agent(self, agent_id: str, capabilities: List[str]):
        """Register a new agent in the system."""
        self.agents[agent_id] = {
            "capabilities": capabilities,
            "status": "active",
            "load": 0.0
        }
        
    async def send_message(self, message: AgentMessage):
        """Send message between agents."""
        await self.message_queue.put(message)
        
    async def process_messages(self):
        """Process pending messages."""
        while not self.message_queue.empty():
            message = await self.message_queue.get()
            await self._handle_message(message)
            
    async def _handle_message(self, message: AgentMessage):
        """Handle incoming message."""
        if message.receiver_id in self.agents:
            # Update shared knowledge
            await self.shared_knowledge.update(message)
            # Coordinate task if needed
            await self.coordinator.process_message(message)

class SharedKnowledge:
    def __init__(self):
        self.knowledge_base = {}
        self.version = 0
        self.lock = asyncio.Lock()
        
    async def update(self, message: AgentMessage):
        """Update shared knowledge."""
        async with self.lock:
            key = f"{message.sender_id}_{self.version}"
            self.knowledge_base[key] = message.content
            self.version += 1
            
    async def query(self, query: str) -> List[Any]:
        """Query shared knowledge."""
        async with self.lock:
            # Implement knowledge search
            return [v for v in self.knowledge_base.values() 
                   if self._matches_query(v, query)]
    
    def _matches_query(self, content: Any, query: str) -> bool:
        """Check if content matches query."""
        return query.lower() in str(content).lower()

class TaskCoordinator:
    def __init__(self):
        self.tasks = {}
        self.agent_loads = {}
        
    async def process_message(self, message: AgentMessage):
        """Process message for task coordination."""
        if self._is_task_request(message):
            await self._coordinate_task(message)
    
    async def _coordinate_task(self, message: AgentMessage):
        """Coordinate task execution."""
        task_id = f"task_{len(self.tasks)}"
        self.tasks[task_id] = {
            "message": message,
            "status": "pending",
            "assigned_to": None
        }
        
        # Find best agent for task
        best_agent = await self._find_best_agent(message)
        if best_agent:
            self.tasks[task_id]["assigned_to"] = best_agent
            self.tasks[task_id]["status"] = "assigned"
            
    async def _find_best_agent(self, message: AgentMessage) -> Optional[str]:
        """Find best agent for task based on load and capabilities."""
        min_load = float('inf')
        best_agent = None
        
        for agent_id, info in self.agent_loads.items():
            if info["load"] < min_load:
                min_load = info["load"]
                best_agent = agent_id
                
        return best_agent
    
    def _is_task_request(self, message: AgentMessage) -> bool:
        """Check if message is a task request."""
        return "task_request" in str(message.content)

class ConsensusEngine:
    def __init__(self, min_consensus: float = 0.7):
        self.min_consensus = min_consensus
        self.votes = {}
        
    async def submit_vote(self, decision_id: str, agent_id: str, vote: Any):
        """Submit a vote for a decision."""
        if decision_id not in self.votes:
            self.votes[decision_id] = {}
        self.votes[decision_id][agent_id] = vote
        
    async def check_consensus(self, decision_id: str) -> Optional[Any]:
        """Check if consensus is reached."""
        if decision_id not in self.votes:
            return None
            
        votes = self.votes[decision_id]
        if not votes:
            return None
            
        # Count votes
        vote_counts = {}
        for vote in votes.values():
            vote_str = str(vote)
            vote_counts[vote_str] = vote_counts.get(vote_str, 0) + 1
            
        # Check for consensus
        total_votes = len(votes)
        for vote, count in vote_counts.items():
            if count / total_votes >= self.min_consensus:
                return vote
                
        return None
