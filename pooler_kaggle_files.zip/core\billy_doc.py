"""
BillyDoc - Self-Healing System for Pooler AI
===========================================

This module implements an intelligent self-healing system that monitors,
diagnoses, and fixes issues in the Pooler AI system.
"""

import os
import sys
import time
import json
import shutil
import logging
import hashlib
import importlib
import traceback
import threading
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
from pathlib import Path

logger = logging.getLogger("pooler_ai.billy_doc")

class BillyDoc:
    """Intelligent self-healing system for Pooler AI."""
    
    def __init__(self, root_dir: str):
        """Initialize BillyDoc.
        
        Args:
            root_dir: Root directory of Pooler AI
        """
        self.root_dir = Path(root_dir)
        self.backup_dir = self.root_dir / "backups"
        self.checksum_file = self.backup_dir / "checksums.json"
        self.error_patterns_file = Path(os.path.dirname(os.path.dirname(__file__))) / "core" / "error_patterns.json"
        
        # Create necessary directories
        self.backup_dir.mkdir(exist_ok=True)
        
        # Initialize specialized processors
        self.code_processor = self._initialize_code_processor()
        self.analytical_engine = self._initialize_analytical_engine()
        
        # Initialize components
        self.checksums = self._load_checksums()
        self.error_patterns = self._load_error_patterns()
        
        # Error tracking
        self.error_history = []
        self.concurrent_errors = []
        self.error_lock = threading.Lock()
        
        # Start monitoring
        self._initialize_monitoring()
        logger.info("BillyDoc initialized and monitoring system")
    
    def _initialize_code_processor(self):
        """Initialize specialized code processor for error detection."""
        try:
            from core.processors import TextProcessor
            processor = TextProcessor()
            logger.info("Initialized code processor")
            return processor
        except Exception as e:
            logger.error(f"Error initializing code processor: {str(e)}")
            return None
    
    def _initialize_analytical_engine(self):
        """Initialize analytical engine for error analysis."""
        try:
            from core.processors import AnalyticalEngine
            engine = AnalyticalEngine()
            logger.info("Initialized analytical engine")
            return engine
        except Exception as e:
            logger.error(f"Error initializing analytical engine: {str(e)}")
            return None
    
    def _load_checksums(self) -> Dict[str, str]:
        """Load file checksums from JSON."""
        if self.checksum_file.exists():
            try:
                with open(self.checksum_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading checksums: {str(e)}")
                return {}
        return {}
    
    def _save_checksums(self) -> None:
        """Save file checksums to JSON."""
        try:
            with open(self.checksum_file, 'w') as f:
                json.dump(self.checksums, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving checksums: {str(e)}")
    
    def _load_error_patterns(self) -> Dict[str, Any]:
        """Load known error patterns and fixes."""
        if self.error_patterns_file.exists():
            try:
                with open(self.error_patterns_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading error patterns: {str(e)}")
                return {}
        return self._create_default_error_patterns()
    
    def _create_default_error_patterns(self) -> Dict[str, Any]:
        """Create default error patterns file."""
        patterns = {
            "import_error": {
                "pattern": "ImportError: No module named '.*'",
                "fix": "pip install {module}"
            },
            "syntax_error": {
                "pattern": "SyntaxError: invalid syntax",
                "fix": "restore_from_backup"
            },
            "indentation_error": {
                "pattern": "IndentationError: .*",
                "fix": "fix_indentation"
            },
            "attribute_error": {
                "pattern": "AttributeError: '.*' object has no attribute '.*'",
                "fix": "restore_from_backup"
            },
            "file_not_found": {
                "pattern": "FileNotFoundError: .*",
                "fix": "create_missing_file"
            },
            "permission_error": {
                "pattern": "PermissionError: .*",
                "fix": "fix_permissions"
            }
        }
        
        try:
            with open(self.error_patterns_file, 'w') as f:
                json.dump(patterns, f, indent=4)
            logger.info("Created default error patterns file")
        except Exception as e:
            logger.error(f"Error creating error patterns file: {str(e)}")
        
        return patterns
    
    def _calculate_checksum(self, file_path: Path) -> str:
        """Calculate MD5 checksum of a file."""
        try:
            with open(file_path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except Exception as e:
            logger.error(f"Error calculating checksum for {file_path}: {str(e)}")
            return ""
    
    def _create_backup(self, file_path: Path) -> None:
        """Create backup of a file."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = self.backup_dir / f"{file_path.name}.{timestamp}.bak"
            shutil.copy2(file_path, backup_path)
            logger.info(f"Created backup of {file_path} at {backup_path}")
        except Exception as e:
            logger.error(f"Error creating backup of {file_path}: {str(e)}")
    
    def _restore_from_backup(self, file_path: Path) -> bool:
        """Restore file from most recent backup."""
        try:
            # Find most recent backup
            backups = list(self.backup_dir.glob(f"{file_path.name}.*.bak"))
            if not backups:
                logger.error(f"No backup found for {file_path}")
                return False
            
            latest_backup = max(backups, key=lambda p: p.stat().st_mtime)
            shutil.copy2(latest_backup, file_path)
            logger.info(f"Restored {file_path} from {latest_backup}")
            return True
        except Exception as e:
            logger.error(f"Error restoring {file_path} from backup: {str(e)}")
            return False
    
    def _fix_indentation(self, file_path: Path) -> bool:
        """Fix indentation issues in a Python file."""
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
            
            fixed_lines = []
            current_indent = 0
            
            for line in lines:
                stripped = line.lstrip()
                if stripped:  # Non-empty line
                    # Calculate proper indentation
                    if stripped.startswith(('def ', 'class ', 'if ', 'elif ', 'else:', 'try:', 'except ', 'finally:', 'while ', 'for ')):
                        indent = ' ' * (4 * current_indent)
                        current_indent += 1
                    elif stripped.startswith(('return ', 'break', 'continue', 'pass')):
                        current_indent = max(0, current_indent - 1)
                        indent = ' ' * (4 * current_indent)
                    else:
                        indent = ' ' * (4 * current_indent)
                    
                    fixed_lines.append(indent + stripped)
                else:
                    fixed_lines.append('\n')
            
            # Create backup before modifying
            self._create_backup(file_path)
            
            # Write fixed content
            with open(file_path, 'w') as f:
                f.writelines(fixed_lines)
            
            logger.info(f"Fixed indentation in {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error fixing indentation in {file_path}: {str(e)}")
            return False
    
    def _create_missing_file(self, file_path: Path) -> bool:
        """Create missing file with default content."""
        try:
            # Create parent directories if they don't exist
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Create empty file with proper Python header
            with open(file_path, 'w') as f:
                f.write('"""\n')
                f.write(f'{file_path.stem.title()} Module\n')
                f.write('=============\n\n')
                f.write(f'This module was automatically created by BillyDoc.\n')
                f.write('"""\n\n')
            
            logger.info(f"Created missing file {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error creating missing file {file_path}: {str(e)}")
            return False
    
    def _fix_permissions(self, file_path: Path) -> bool:
        """Fix file permissions."""
        try:
            # Make file readable and writable
            os.chmod(file_path, 0o644)
            logger.info(f"Fixed permissions for {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error fixing permissions for {file_path}: {str(e)}")
            return False
    
    def _initialize_monitoring(self) -> None:
        """Initialize system monitoring."""
        try:
            # Monitor Python files in project
            for file_path in self.root_dir.rglob("*.py"):
                if file_path.is_file():
                    checksum = self._calculate_checksum(file_path)
                    self.checksums[str(file_path)] = checksum
            
            # Save initial checksums
            self._save_checksums()
            logger.info("Initialized file monitoring")
        except Exception as e:
            logger.error(f"Error initializing monitoring: {str(e)}")
    
    def check_system_health(self) -> Dict[str, Any]:
        """Check overall system health."""
        health_report = {
            "timestamp": datetime.now().isoformat(),
            "status": "healthy",
            "issues": [],
            "modified_files": [],
            "missing_files": [],
            "memory_usage": self._check_memory_usage(),
            "performance_metrics": self._check_performance(),
            "thread_state": self._check_thread_state(),
            "resource_usage": self._check_resource_usage(),
            "concurrent_errors": self._get_concurrent_errors()
        }
        
        try:
            # Check for modified files
            for file_path_str, stored_checksum in self.checksums.items():
                file_path = Path(file_path_str)
                if file_path.exists():
                    current_checksum = self._calculate_checksum(file_path)
                    if current_checksum != stored_checksum:
                        health_report["modified_files"].append(str(file_path))
                else:
                    health_report["missing_files"].append(str(file_path))
            
            # Update status based on findings
            if health_report["issues"] or health_report["modified_files"] or health_report["missing_files"] or health_report["concurrent_errors"]:
                health_report["status"] = "issues_detected"
            
            logger.info(f"Health check completed: {health_report['status']}")
            return health_report
        except Exception as e:
            logger.error(f"Error during health check: {str(e)}")
            health_report["status"] = "check_failed"
            health_report["issues"].append(str(e))
            return health_report
    
    def diagnose_error(self, error: Exception, context: Dict[str, Any] = None) -> Tuple[str, Optional[str]]:
        """Diagnose an error and determine fix strategy."""
        error_str = str(error)
        traceback_str = traceback.format_exc()
        
        # Track error for concurrent error detection
        self._track_error(error, traceback_str)
        
        # Use code processor for enhanced error analysis
        if self.code_processor:
            try:
                code_analysis = self.code_processor.process(error_str + "\n" + traceback_str)
                if code_analysis["confidence"] > 0.6:  # Use confidence threshold from memory
                    # Extract relevant error patterns from analysis
                    error_features = code_analysis.get("features", None)
                    if error_features is not None and self.analytical_engine:
                        analysis = self.analytical_engine.process({
                            "features": error_features,
                            "context": context
                        })
                        if analysis["confidence"] > 0.7:  # Higher threshold for fixes
                            # Use analytical results to enhance error diagnosis
                            error_type = self._get_error_type_from_analysis(analysis)
                            if error_type:
                                return error_type, self.error_patterns.get(error_type, {}).get("fix")
            except Exception as e:
                logger.error(f"Error in enhanced error diagnosis: {str(e)}")
        
        # Fallback to basic pattern matching
        for error_type, pattern_data in self.error_patterns.items():
            if pattern_data["pattern"] in error_str or pattern_data["pattern"] in traceback_str:
                return error_type, pattern_data["fix"]
        
        logger.warning(f"Unknown error pattern: {error_str}")
        return "unknown_error", None
    
    def _track_error(self, error: Exception, traceback_str: str) -> None:
        """Track errors to detect patterns and concurrent issues."""
        try:
            with self.error_lock:
                timestamp = time.time()
                error_info = {
                    "timestamp": timestamp,
                    "type": type(error).__name__,
                    "message": str(error),
                    "traceback": traceback_str,
                    "thread": threading.current_thread().name,
                    "severity": self._determine_error_severity(error)
                }
                
                # Add to error history
                self.error_history.append(error_info)
                
                # Keep only recent errors (last 5 minutes)
                cutoff_time = timestamp - 300
                self.error_history = [e for e in self.error_history if e["timestamp"] >= cutoff_time]
                
                # Detect concurrent errors (within 5 seconds of each other)
                recent_errors = [e for e in self.error_history if timestamp - e["timestamp"] <= 5]
                if len(recent_errors) > 1:
                    # Group by error type
                    error_types = set(e["type"] for e in recent_errors)
                    if len(error_types) > 1:
                        # Multiple different error types occurring concurrently
                        concurrent_group = {
                            "timestamp": timestamp,
                            "errors": recent_errors,
                            "related": self._check_error_relation(recent_errors),
                            "root_cause": self._identify_root_cause(recent_errors),
                            "cascade_pattern": self._detect_cascade_pattern(recent_errors)
                        }
                        self.concurrent_errors.append(concurrent_group)
                        logger.warning(f"Detected concurrent errors: {error_types}")
        except Exception as e:
            logger.error(f"Error tracking error: {str(e)}")
    
    def _determine_error_severity(self, error: Exception) -> str:
        """Determine the severity of an error."""
        # Critical errors that might cause system failure
        critical_errors = (
            SystemError, MemoryError, RecursionError, 
            ImportError, ModuleNotFoundError
        )
        
        # High severity errors that affect functionality
        high_severity_errors = (
            TypeError, ValueError, AttributeError, 
            FileNotFoundError, PermissionError
        )
        
        # Medium severity errors that might be recoverable
        medium_severity_errors = (
            KeyError, IndexError, ZeroDivisionError
        )
        
        if isinstance(error, critical_errors):
            return "critical"
        elif isinstance(error, high_severity_errors):
            return "high"
        elif isinstance(error, medium_severity_errors):
            return "medium"
        else:
            return "low"
    
    def _identify_root_cause(self, errors: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Identify the potential root cause from a group of concurrent errors."""
        try:
            # Sort errors by timestamp and severity
            sorted_errors = sorted(
                errors, 
                key=lambda e: (e["timestamp"], self._severity_score(e["severity"]))
            )
            
            # The earliest critical/high severity error is likely the root cause
            for error in sorted_errors:
                if error["severity"] in ("critical", "high"):
                    return error
            
            # If no critical/high severity errors, return the earliest error
            return sorted_errors[0] if sorted_errors else None
        except Exception as e:
            logger.error(f"Error identifying root cause: {str(e)}")
            return None
    
    def _severity_score(self, severity: str) -> int:
        """Convert severity string to numeric score for sorting."""
        scores = {
            "critical": 0,
            "high": 1,
            "medium": 2,
            "low": 3
        }
        return scores.get(severity, 4)
    
    def _detect_cascade_pattern(self, errors: List[Dict[str, Any]]) -> str:
        """Detect if errors follow a cascade pattern."""
        try:
            # Sort errors by timestamp
            sorted_errors = sorted(errors, key=lambda e: e["timestamp"])
            
            # Check time intervals between errors
            intervals = [
                sorted_errors[i+1]["timestamp"] - sorted_errors[i]["timestamp"]
                for i in range(len(sorted_errors) - 1)
            ]
            
            # If intervals are very small and decreasing, it might be a cascade failure
            if intervals and all(i < 0.5 for i in intervals):
                if all(intervals[i] <= intervals[i-1] for i in range(1, len(intervals))):
                    return "accelerating_cascade"
                return "rapid_cascade"
            
            # Check if errors are in different components
            error_files = set()
            for error in sorted_errors:
                for line in error["traceback"].split("\n"):
                    if "File" in line and ".py" in line:
                        parts = line.split('"')
                        if len(parts) > 1:
                            error_files.add(parts[1])
            
            if len(error_files) > 1:
                return "cross_component_cascade"
            
            return "independent_errors"
        except Exception as e:
            logger.error(f"Error detecting cascade pattern: {str(e)}")
            return "unknown_pattern"
    
    def _check_error_relation(self, errors: List[Dict[str, Any]]) -> bool:
        """Check if errors are related to each other."""
        try:
            # Check for common patterns in tracebacks
            tracebacks = [e["traceback"] for e in errors]
            common_files = set()
            
            for tb in tracebacks:
                for line in tb.split("\n"):
                    if "File" in line and ".py" in line:
                        # Extract filename from traceback
                        parts = line.split('"')
                        if len(parts) > 1:
                            filename = parts[1]
                            common_files.add(filename)
            
            # If errors share common files, they might be related
            return len(common_files) < len(errors)
        except Exception as e:
            logger.error(f"Error checking error relation: {str(e)}")
            return False
    
    def _get_concurrent_errors(self) -> List[Dict[str, Any]]:
        """Get information about concurrent errors."""
        try:
            with self.error_lock:
                # Clean up old concurrent error groups
                current_time = time.time()
                self.concurrent_errors = [
                    e for e in self.concurrent_errors 
                    if current_time - e["timestamp"] <= 300  # Keep errors from last 5 minutes
                ]
                
                # Format for reporting
                return [
                    {
                        "timestamp": datetime.fromtimestamp(e["timestamp"]).isoformat(),
                        "error_count": len(e["errors"]),
                        "error_types": list(set(err["type"] for err in e["errors"])),
                        "related": e["related"],
                        "cascade_pattern": e.get("cascade_pattern", "unknown_pattern"),
                        "root_cause": {
                            "type": e.get("root_cause", {}).get("type", "unknown"),
                            "message": e.get("root_cause", {}).get("message", "")
                        } if e.get("root_cause") else None,
                        "recommendation": self._generate_recommendation(e)
                    }
                    for e in self.concurrent_errors
                ]
        except Exception as e:
            logger.error(f"Error getting concurrent errors: {str(e)}")
            return []
    
    def _generate_recommendation(self, error_group: Dict[str, Any]) -> str:
        """Generate a recommendation for fixing concurrent errors."""
        try:
            pattern = error_group.get("cascade_pattern", "unknown_pattern")
            related = error_group.get("related", False)
            
            if pattern == "accelerating_cascade":
                return "Urgent: Fix root cause immediately to prevent system failure"
            elif pattern == "rapid_cascade":
                return "High priority: Address root cause to stop cascading failures"
            elif pattern == "cross_component_cascade":
                return "Check component dependencies and interaction points"
            elif related:
                return "Fix root cause first, then verify all related components"
            else:
                return "Address each error independently, starting with highest severity"
        except Exception as e:
            logger.error(f"Error generating recommendation: {str(e)}")
            return "Check for cascading failures or race conditions"
    
    def fix_issue(self, file_path: Path, error_type: str, fix_strategy: str) -> bool:
        """Fix an identified issue."""
        logger.info(f"Attempting to fix {error_type} in {file_path} using {fix_strategy}")
        
        try:
            # Create backup before fixing
            self._create_backup(file_path)
            
            # Use code processor for enhanced fixing
            if self.code_processor and error_type in ["syntax_error", "indentation_error"]:
                try:
                    with open(file_path, 'r') as f:
                        code_content = f.read()
                    
                    # Analyze code with processor
                    analysis = self.code_processor.process(code_content)
                    if analysis["confidence"] > 0.6:  # Use confidence threshold from memory
                        # Use analytical engine for fix validation
                        if self.analytical_engine:
                            validation = self.analytical_engine.process({
                                "features": analysis["features"],
                                "error_type": error_type,
                                "fix_strategy": fix_strategy
                            })
                            if validation["confidence"] > 0.7:  # Higher threshold for fixes
                                # Apply enhanced fix
                                success = self._apply_enhanced_fix(file_path, analysis, validation)
                                if success:
                                    return True
                except Exception as e:
                    logger.error(f"Error in enhanced fixing: {str(e)}")
            
            # Fallback to basic fix strategies
            if fix_strategy == "restore_from_backup":
                success = self._restore_from_backup(file_path)
            elif fix_strategy == "fix_indentation":
                success = self._fix_indentation(file_path)
            elif fix_strategy == "create_missing_file":
                success = self._create_missing_file(file_path)
            elif fix_strategy == "fix_permissions":
                success = self._fix_permissions(file_path)
            elif fix_strategy.startswith("pip install"):
                module = fix_strategy.split()[-1]
                try:
                    import pip
                    pip.main(['install', module])
                    success = True
                except Exception as e:
                    logger.error(f"Error installing module {module}: {str(e)}")
                    success = False
            else:
                logger.error(f"Unknown fix strategy: {fix_strategy}")
                success = False
            
            if success:
                # Update checksum after successful fix
                self.checksums[str(file_path)] = self._calculate_checksum(file_path)
                self._save_checksums()
                logger.info(f"Successfully fixed {error_type} in {file_path}")
            
            return success
        except Exception as e:
            logger.error(f"Error fixing {error_type} in {file_path}: {str(e)}")
            return False
    
    def _apply_enhanced_fix(self, file_path: Path, analysis: Dict[str, Any], validation: Dict[str, Any]) -> bool:
        """Apply enhanced fix using processor analysis."""
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
            
            # Extract fix suggestions from validation
            thoughts = validation.get("thoughts", [])
            if thoughts:
                fixed_lines = lines.copy()
                for thought in thoughts:
                    content = thought.get("content", None)
                    if content is not None and isinstance(content, torch.Tensor):
                        # Convert tensor suggestions to text
                        suggestion = content.tolist()
                        # Apply suggestions to relevant lines
                        for i, line in enumerate(fixed_lines):
                            if i < len(suggestion):
                                fixed_lines[i] = self._apply_suggestion(line, suggestion[i])
                
                # Write fixed content
                with open(file_path, 'w') as f:
                    f.writelines(fixed_lines)
                
                logger.info(f"Applied enhanced fix to {file_path}")
                return True
        except Exception as e:
            logger.error(f"Error applying enhanced fix: {str(e)}")
        return False
    
    def _apply_suggestion(self, line: str, suggestion: float) -> str:
        """Apply a suggestion to a line of code."""
        try:
            # Use suggestion value to determine fix
            if suggestion > 0.8:  # High confidence fix
                return line.strip() + '\n'  # Remove extra whitespace
            elif suggestion > 0.6:  # Medium confidence fix
                return ' ' * (4 * (len(line) - len(line.lstrip()))) + line.lstrip()  # Fix indentation
            else:
                return line  # Keep original if low confidence
        except Exception as e:
            logger.error(f"Error applying suggestion: {str(e)}")
            return line
    
    def _check_memory_usage(self) -> Dict[str, Any]:
        """Monitor memory usage and detect leaks."""
        try:
            import psutil
            process = psutil.Process()
            
            memory_info = process.memory_info()
            
            memory_data = {
                "rss": memory_info.rss,  # Resident Set Size
                "vms": memory_info.vms,  # Virtual Memory Size
                "percent": process.memory_percent(),
                "growth_rate": self._calculate_memory_growth_rate(),
                "potential_leaks": []
            }
            
            # Check for memory leaks
            if memory_data["growth_rate"] > 10:  # More than 10% growth rate
                memory_data["potential_leaks"].append({
                    "type": "continuous_growth",
                    "growth_rate": memory_data["growth_rate"],
                    "recommendation": "Check for unbounded data structures or resource leaks"
                })
            
            return memory_data
        except Exception as e:
            logger.error(f"Error checking memory usage: {str(e)}")
            return {"error": str(e)}
    
    def _calculate_memory_growth_rate(self) -> float:
        """Calculate memory growth rate over time."""
        try:
            import psutil
            process = psutil.Process()
            
            # Take two measurements
            mem1 = process.memory_info().rss
            time.sleep(1)
            mem2 = process.memory_info().rss
            
            # Calculate growth rate as percentage
            if mem1 > 0:
                return ((mem2 - mem1) / mem1) * 100
            return 0
        except Exception as e:
            logger.error(f"Error calculating memory growth rate: {str(e)}")
            return 0
    
    def _check_performance(self) -> Dict[str, Any]:
        """Monitor system performance."""
        try:
            import psutil
            
            metrics = {
                "cpu_percent": psutil.cpu_percent(interval=1),
                "io_counters": dict(psutil.disk_io_counters()._asdict()),
                "slow_functions": self._detect_slow_functions(),
                "bottlenecks": []
            }
            
            # Check for performance bottlenecks
            if metrics["cpu_percent"] > 80:
                metrics["bottlenecks"].append({
                    "type": "high_cpu",
                    "value": metrics["cpu_percent"],
                    "recommendation": "Optimize CPU-intensive operations"
                })
            
            return metrics
        except Exception as e:
            logger.error(f"Error checking performance: {str(e)}")
            return {"error": str(e)}
    
    def _detect_slow_functions(self) -> List[Dict[str, Any]]:
        """Detect slow or inefficient functions."""
        slow_functions = []
        
        try:
            import cProfile
            import pstats
            import io
            
            # Profile recent function calls
            pr = cProfile.Profile()
            pr.enable()
            
            # Let it run for a short time
            time.sleep(0.1)
            
            pr.disable()
            s = io.StringIO()
            ps = pstats.Stats(pr, stream=s).sort_stats('cumulative')
            ps.print_stats()
            
            # Analyze profiling data
            for line in s.getvalue().split('\n'):
                if 'function calls' not in line and '/usr/lib' not in line:
                    if 'seconds' in line:
                        parts = line.strip().split()
                        if len(parts) >= 4:
                            time_taken = float(parts[3])
                            if time_taken > 0.1:  # Functions taking more than 100ms
                                slow_functions.append({
                                    "function": parts[-1],
                                    "time": time_taken,
                                    "recommendation": "Consider optimization or caching"
                                })
            
            return slow_functions
        except Exception as e:
            logger.error(f"Error detecting slow functions: {str(e)}")
            return []
    
    def _check_thread_state(self) -> Dict[str, Any]:
        """Monitor thread state and detect deadlocks."""
        try:
            import threading
            
            thread_info = {
                "active_count": threading.active_count(),
                "current_thread": threading.current_thread().name,
                "all_threads": [t.name for t in threading.enumerate()],
                "deadlocks": self._detect_deadlocks(),
                "blocked_threads": []
            }
            
            # Check for blocked threads
            for thread in threading.enumerate():
                if thread.is_alive() and not thread.daemon:
                    if hasattr(thread, "_block_start_time"):
                        block_duration = time.time() - thread._block_start_time
                        if block_duration > 5:  # Blocked for more than 5 seconds
                            thread_info["blocked_threads"].append({
                                "thread": thread.name,
                                "duration": block_duration,
                                "recommendation": "Check for deadlocks or long-running operations"
                            })
            
            return thread_info
        except Exception as e:
            logger.error(f"Error checking thread state: {str(e)}")
            return {"error": str(e)}
    
    def _detect_deadlocks(self) -> List[Dict[str, Any]]:
        """Detect potential deadlocks."""
        try:
            import threading
            
            deadlocks = []
            lock_graph = {}
            
            # Build lock dependency graph
            for thread in threading.enumerate():
                if hasattr(thread, "_acquired_locks"):
                    locks = thread._acquired_locks
                    for i in range(len(locks) - 1):
                        lock_graph[locks[i]] = locks[i + 1]
            
            # Check for cycles in lock graph (indicating deadlock)
            visited = set()
            for lock in lock_graph:
                if lock not in visited:
                    path = []
                    current = lock
                    while current in lock_graph:
                        if current in path:
                            # Found a cycle
                            cycle_start = path.index(current)
                            deadlock_chain = path[cycle_start:]
                            deadlocks.append({
                                "locks": [str(l) for l in deadlock_chain],
                                "recommendation": "Ensure consistent lock acquisition order"
                            })
                            break
                        path.append(current)
                        current = lock_graph[current]
                        visited.add(current)
            
            return deadlocks
        except Exception as e:
            logger.error(f"Error detecting deadlocks: {str(e)}")
            return []
    
    def _check_resource_usage(self) -> Dict[str, Any]:
        """Monitor system resource usage."""
        try:
            import psutil
            
            usage = {
                "open_files": len(psutil.Process().open_files()),
                "connections": len(psutil.Process().connections()),
                "disk_usage": psutil.disk_usage('/'),
                "warnings": []
            }
            
            # Check for resource exhaustion
            if usage["open_files"] > 900:  # Close to ulimit
                usage["warnings"].append({
                    "type": "high_file_descriptors",
                    "value": usage["open_files"],
                    "recommendation": "Close unused files or increase ulimit"
                })
            
            if usage["disk_usage"].percent > 90:
                usage["warnings"].append({
                    "type": "low_disk_space",
                    "value": usage["disk_usage"].percent,
                    "recommendation": "Free up disk space or expand storage"
                })
            
            return usage
        except Exception as e:
            logger.error(f"Error checking resource usage: {str(e)}")
            return {"error": str(e)}
    
    def fix_memory_leak(self, leak_info: Dict[str, Any]) -> bool:
        """Fix detected memory leak."""
        try:
            import gc
            
            # Force garbage collection
            gc.collect()
            
            # Clear any large caches
            if hasattr(self, '_cache'):
                self._cache.clear()
            
            # Log fix attempt
            logger.info(f"Attempted to fix memory leak: {leak_info}")
            return True
        except Exception as e:
            logger.error(f"Error fixing memory leak: {str(e)}")
            return False
    
    def fix_performance_issue(self, performance_info: Dict[str, Any]) -> bool:
        """Fix detected performance issue."""
        try:
            # Implement performance optimization strategies
            if "high_cpu" in str(performance_info.get("type", "")):
                # Reduce thread count or workload
                pass
            elif "slow_function" in str(performance_info.get("type", "")):
                # Apply caching or optimization
                pass
            
            # Log fix attempt
            logger.info(f"Attempted to fix performance issue: {performance_info}")
            return True
        except Exception as e:
            logger.error(f"Error fixing performance issue: {str(e)}")
            return False
    
    def fix_deadlock(self, deadlock_info: Dict[str, Any]) -> bool:
        """Fix detected deadlock."""
        try:
            import threading
            
            # Force release locks in reverse order
            for lock_str in reversed(deadlock_info.get("locks", [])):
                try:
                    # Find the actual lock object
                    for thread in threading.enumerate():
                        if hasattr(thread, "_acquired_locks"):
                            for lock in thread._acquired_locks:
                                if str(lock) == lock_str:
                                    # Force release the lock
                                    if hasattr(lock, "_release"):
                                        lock._release()
                except:
                    pass
            
            # Log fix attempt
            logger.info(f"Attempted to fix deadlock: {deadlock_info}")
            return True
        except Exception as e:
            logger.error(f"Error fixing deadlock: {str(e)}")
            return False
    
    def fix_resource_exhaustion(self, resource_info: Dict[str, Any]) -> bool:
        """Fix resource exhaustion issues."""
        try:
            import psutil
            process = psutil.Process()
            
            if "high_file_descriptors" in str(resource_info.get("type", "")):
                # Close least recently used files
                open_files = process.open_files()
                if len(open_files) > 0:
                    # Sort by access time and close oldest
                    files_by_time = sorted(open_files, key=lambda x: x.path)
                    for file in files_by_time[:len(files_by_time)//2]:
                        try:
                            os.close(file.fd)
                        except:
                            pass
            
            # Log fix attempt
            logger.info(f"Attempted to fix resource exhaustion: {resource_info}")
            return True
        except Exception as e:
            logger.error(f"Error fixing resource exhaustion: {str(e)}")
            return False
    
    def fix_concurrent_errors(self, error_group: Dict[str, Any]) -> bool:
        """Fix a group of concurrent errors."""
        try:
            success = True
            
            # Log detailed information about the concurrent errors
            logger.info(f"Attempting to fix concurrent errors: {error_group['error_types']}")
            logger.info(f"Cascade pattern: {error_group.get('cascade_pattern', 'unknown')}")
            logger.info(f"Recommendation: {error_group.get('recommendation', '')}")
            
            # If errors are related, try to fix the root cause first
            if error_group.get("related", False):
                # Get root cause information
                root_cause_type = error_group.get("root_cause", {}).get("type")
                
                if root_cause_type:
                    logger.info(f"Fixing root cause first: {root_cause_type}")
                
                # Identify potential root cause (usually the first error)
                error_types = error_group.get("error_types", [])
                if "ImportError" in error_types or "ModuleNotFoundError" in error_types:
                    # Fix import issues first
                    self._fix_import_issues()
                elif "SyntaxError" in error_types:
                    # Fix syntax issues
                    self._fix_syntax_issues()
                elif "AttributeError" in error_types:
                    # Fix attribute errors
                    self._fix_attribute_issues()
                elif "PermissionError" in error_types:
                    # Fix permission issues
                    self._fix_permission_issues()
            else:
                # Fix each error independently
                for error_type in error_group.get("error_types", []):
                    if error_type in self.error_patterns:
                        fix_strategy = self.error_patterns[error_type].get("fix")
                        if fix_strategy:
                            # Apply fix for each error type
                            success = success and self._apply_generic_fix(error_type, fix_strategy)
            
            logger.info(f"Attempted to fix concurrent errors: {success}")
            return success
        except Exception as e:
            logger.error(f"Error fixing concurrent errors: {str(e)}")
            return False
    
    def _fix_import_issues(self) -> bool:
        """Fix import-related issues."""
        try:
            # Check for missing modules
            import importlib
            
            # Look for recent import errors
            import_errors = [
                e for e in self.error_history 
                if e["type"] in ("ImportError", "ModuleNotFoundError")
            ]
            
            for error in import_errors:
                # Extract module name from error message
                msg = error["message"]
                if "No module named" in msg:
                    module_name = msg.split("'")[1]
                    try:
                        # Try to install the module
                        import pip
                        pip.main(['install', module_name])
                        logger.info(f"Installed missing module: {module_name}")
                    except Exception as e:
                        logger.error(f"Failed to install module {module_name}: {str(e)}")
            
            return True
        except Exception as e:
            logger.error(f"Error fixing import issues: {str(e)}")
            return False
    
    def _fix_syntax_issues(self) -> bool:
        """Fix syntax-related issues."""
        try:
            # Look for recent syntax errors
            syntax_errors = [
                e for e in self.error_history 
                if e["type"] == "SyntaxError"
            ]
            
            for error in syntax_errors:
                # Extract file from traceback
                tb = error["traceback"]
                file_path = None
                
                for line in tb.split("\n"):
                    if "File" in line and ".py" in line:
                        parts = line.split('"')
                        if len(parts) > 1:
                            file_path = Path(parts[1])
                            break
                
                if file_path and file_path.exists():
                    # Fix the syntax error
                    self.fix_issue(file_path, "syntax_error", "restore_from_backup")
            
            return True
        except Exception as e:
            logger.error(f"Error fixing syntax issues: {str(e)}")
            return False
    
    def _fix_attribute_issues(self) -> bool:
        """Fix attribute-related issues."""
        try:
            # Look for recent attribute errors
            attribute_errors = [
                e for e in self.error_history 
                if e["type"] == "AttributeError"
            ]
            
            for error in attribute_errors:
                # Extract file from traceback
                tb = error["traceback"]
                file_path = None
                
                for line in tb.split("\n"):
                    if "File" in line and ".py" in line:
                        parts = line.split('"')
                        if len(parts) > 1:
                            file_path = Path(parts[1])
                            break
                
                if file_path and file_path.exists():
                    # Fix the attribute error by restoring from backup
                    self.fix_issue(file_path, "attribute_error", "restore_from_backup")
            
            return True
        except Exception as e:
            logger.error(f"Error fixing attribute issues: {str(e)}")
            return False
    
    def _fix_permission_issues(self) -> bool:
        """Fix permission-related issues."""
        try:
            # Look for recent permission errors
            permission_errors = [
                e for e in self.error_history 
                if e["type"] == "PermissionError"
            ]
            
            for error in permission_errors:
                # Extract file from traceback
                tb = error["traceback"]
                file_path = None
                
                for line in tb.split("\n"):
                    if "File" in line and ".py" in line:
                        parts = line.split('"')
                        if len(parts) > 1:
                            file_path = Path(parts[1])
                            break
                
                if file_path and file_path.exists():
                    # Fix the permission error
                    self.fix_issue(file_path, "permission_error", "fix_permissions")
            
            return True
        except Exception as e:
            logger.error(f"Error fixing permission issues: {str(e)}")
            return False
    
    def _apply_generic_fix(self, error_type: str, fix_strategy: str) -> bool:
        """Apply a generic fix for an error type."""
        try:
            if fix_strategy.startswith("pip install"):
                module = fix_strategy.split()[-1]
                try:
                    import pip
                    pip.main(['install', module])
                    return True
                except Exception as e:
                    logger.error(f"Error installing module {module}: {str(e)}")
                    return False
            else:
                logger.info(f"Applied generic fix for {error_type}: {fix_strategy}")
                return True
        except Exception as e:
            logger.error(f"Error applying generic fix: {str(e)}")
            return False
    
    def monitor_and_fix(self) -> None:
        """Continuously monitor system and fix issues."""
        while True:
            try:
                # Check system health
                health_report = self.check_system_health()
                
                # Fix issues if detected
                if health_report["status"] == "issues_detected":
                    # Fix modified files
                    for file_path_str in health_report["modified_files"]:
                        file_path = Path(file_path_str)
                        # Check if file has syntax errors
                        try:
                            with open(file_path, 'r') as f:
                                content = f.read()
                            
                            # Try to compile to check for syntax errors
                            try:
                                compile(content, file_path, 'exec')
                            except SyntaxError:
                                # Fix syntax error
                                self.fix_issue(file_path, "syntax_error", "restore_from_backup")
                        except Exception as e:
                            logger.error(f"Error checking file {file_path}: {str(e)}")
                    
                    # Fix missing files
                    for file_path_str in health_report["missing_files"]:
                        file_path = Path(file_path_str)
                        self.fix_issue(file_path, "file_not_found", "create_missing_file")
                    
                    # Handle memory leaks
                    if health_report["memory_usage"]["potential_leaks"]:
                        for leak in health_report["memory_usage"]["potential_leaks"]:
                            self.fix_memory_leak(leak)
                    
                    # Handle performance issues
                    if health_report["performance_metrics"]["bottlenecks"]:
                        for bottleneck in health_report["performance_metrics"]["bottlenecks"]:
                            self.fix_performance_issue(bottleneck)
                    
                    # Handle deadlocks
                    if health_report["thread_state"]["deadlocks"]:
                        for deadlock in health_report["thread_state"]["deadlocks"]:
                            self.fix_deadlock(deadlock)
                    
                    # Handle resource exhaustion
                    if health_report["resource_usage"]["warnings"]:
                        for warning in health_report["resource_usage"]["warnings"]:
                            self.fix_resource_exhaustion(warning)
                    
                    # Handle concurrent errors
                    if health_report["concurrent_errors"]:
                        for error_group in health_report["concurrent_errors"]:
                            self.fix_concurrent_errors(error_group)
                
                # Wait before next check
                time.sleep(5)
            except Exception as e:
                logger.error(f"Error in monitoring loop: {str(e)}")
                time.sleep(5)  # Wait before retrying
    
    def start(self) -> None:
        """Start BillyDoc system."""
        logger.info("Starting BillyDoc monitoring system")
        self.monitor_and_fix()

# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("billy_doc.log"),
            logging.StreamHandler()
        ]
    )
    
    # Start BillyDoc
    billy = BillyDoc(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    billy.start()
