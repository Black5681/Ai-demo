import sqlite3
import json
import time
import os
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import numpy as np
from google.cloud import storage

logger = logging.getLogger(__name__)

@dataclass
class Thought:
    """Represents a complex thought stored in the AI's mind."""
    id: Optional[int]
    content: str
    category: str
    importance: float  # 0.0 to 1.0
    associations: List[str]
    created_at: float
    last_accessed: float
    access_count: int
    embedding: Optional[np.ndarray] = None
    metadata: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert thought to dictionary for storage."""
        return {
            "id": self.id,
            "content": self.content,
            "category": self.category,
            "importance": self.importance,
            "associations": json.dumps(self.associations),
            "created_at": self.created_at,
            "last_accessed": self.last_accessed,
            "access_count": self.access_count,
            "embedding": self.embedding.tobytes() if self.embedding is not None else None,
            "emotional_data": self.metadata.get("emotional_data") if self.metadata else None
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Thought':
        """Create thought from dictionary."""
        associations = json.loads(data["associations"]) if isinstance(data["associations"], str) else data["associations"]
        embedding = None
        if data.get("embedding") is not None:
            if isinstance(data["embedding"], bytes):
                embedding = np.frombuffer(data["embedding"], dtype=np.float32)
            else:
                embedding = data["embedding"]
                
        metadata = None
        if data.get("emotional_data") is not None:
            metadata = {"emotional_data": data["emotional_data"]}
                
        return cls(
            id=data.get("id"),
            content=data["content"],
            category=data["category"],
            importance=data["importance"],
            associations=associations,
            created_at=data["created_at"],
            last_accessed=data["last_accessed"],
            access_count=data["access_count"],
            embedding=embedding,
            metadata=metadata
        )

class MindDatabase:
    """Database for storing and retrieving complex thoughts."""
    
    def __init__(self, db_path: str = "mind_database.sqlite", embedding_dim: int = 2048):
        """Initialize the mind database.
        
        Args:
            db_path: Path to the SQLite database file
            embedding_dim: Dimension of thought embeddings
        """
        self.db_path = db_path
        self.embedding_dim = embedding_dim
        self.conn = None
        self.cursor = None
        self.initialize_database()
        
        # For fast learning and adaptation - enhanced learning rate
        self.learning_rate = 0.15  # Increased from 0.1 for faster learning
        self.recent_thoughts = []
        self.max_recent_thoughts = 750  # Increased from 500 for better memory
        self.emotional_patterns = {}  # Track emotional patterns
        
        # Performance settings
        self.cache_size = 15000  # Increased from 10000 entries
        self.importance_threshold = 0.55  # Decreased from 0.6 to store more thoughts
        self.similarity_threshold = 0.65  # Decreased from 0.7 for broader associations
        
    def initialize_database(self):
        """Create database tables if they don't exist."""
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        
        # Create thoughts table
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS thoughts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            category TEXT NOT NULL,
            importance REAL NOT NULL,
            associations TEXT NOT NULL,
            created_at REAL NOT NULL,
            last_accessed REAL NOT NULL,
            access_count INTEGER NOT NULL,
            embedding BLOB,
            emotional_data TEXT
        )
        """)
        
        # Create associations table for fast querying
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS thought_associations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            thought_id INTEGER NOT NULL,
            association TEXT NOT NULL,
            FOREIGN KEY (thought_id) REFERENCES thoughts (id) ON DELETE CASCADE
        )
        """)
        
        # Create index on associations
        self.cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_thought_associations_association 
        ON thought_associations (association)
        """)
        
        # Create index on category
        self.cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_thoughts_category 
        ON thoughts (category)
        """)
        
        self.conn.commit()
        
    def close(self):
        """Close the database connection."""
        if self.conn:
            self.conn.close()
            
    def __del__(self):
        """Ensure database connection is closed on deletion."""
        self.close()
    
    def store_thought(self, thought: Thought) -> int:
        """Store a new thought in the database.
        
        Args:
            thought: The thought to store
            
        Returns:
            The ID of the stored thought
        """
        # Set creation time if not set
        if thought.created_at is None:
            thought.created_at = time.time()
            
        # Set last accessed time if not set
        if thought.last_accessed is None:
            thought.last_accessed = thought.created_at
            
        # Insert thought into database
        self.cursor.execute("""
        INSERT INTO thoughts 
        (content, category, importance, associations, created_at, last_accessed, access_count, embedding, emotional_data)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            thought.content,
            thought.category,
            thought.importance,
            json.dumps(thought.associations),
            thought.created_at,
            thought.last_accessed,
            thought.access_count,
            thought.embedding.tobytes() if thought.embedding is not None else None,
            json.dumps(thought.metadata.get("emotional_data")) if thought.metadata else None
        ))
        
        # Get the ID of the inserted thought
        thought_id = self.cursor.lastrowid
        
        # Insert associations for fast querying
        for association in thought.associations:
            self.cursor.execute("""
            INSERT INTO thought_associations (thought_id, association)
            VALUES (?, ?)
            """, (thought_id, association))
        
        self.conn.commit()
        
        # Add to recent thoughts for fast learning
        thought.id = thought_id
        self._add_to_recent_thoughts(thought)
        
        return thought_id
    
    def get_thought(self, thought_id: int) -> Optional[Thought]:
        """Retrieve a thought by ID.
        
        Args:
            thought_id: The ID of the thought to retrieve
            
        Returns:
            The thought if found, None otherwise
        """
        self.cursor.execute("""
        SELECT id, content, category, importance, associations, created_at, last_accessed, access_count, embedding, emotional_data
        FROM thoughts
        WHERE id = ?
        """, (thought_id,))
        
        row = self.cursor.fetchone()
        if not row:
            return None
            
        # Update access count and last accessed time
        self.cursor.execute("""
        UPDATE thoughts
        SET access_count = access_count + 1, last_accessed = ?
        WHERE id = ?
        """, (time.time(), thought_id))
        self.conn.commit()
        
        # Create thought object
        thought = Thought(
            id=row[0],
            content=row[1],
            category=row[2],
            importance=row[3],
            associations=json.loads(row[4]),
            created_at=row[5],
            last_accessed=row[6],
            access_count=row[7] + 1,  # Include the current access
            embedding=np.frombuffer(row[8], dtype=np.float32) if row[8] else None,
            metadata={"emotional_data": json.loads(row[9])} if row[9] else None
        )
        
        # Add to recent thoughts for fast learning
        self._add_to_recent_thoughts(thought)
        
        return thought
    
    def search_thoughts(self, query: str, category: Optional[str] = None, limit: int = 10) -> List[Thought]:
        """Search for thoughts based on content and category.
        
        Args:
            query: The search query
            category: Optional category to filter by
            limit: Maximum number of results to return
            
        Returns:
            List of matching thoughts
        """
        if category:
            self.cursor.execute("""
            SELECT id, content, category, importance, associations, created_at, last_accessed, access_count, embedding, emotional_data
            FROM thoughts
            WHERE content LIKE ? AND category = ?
            ORDER BY importance DESC, last_accessed DESC
            LIMIT ?
            """, (f"%{query}%", category, limit))
        else:
            self.cursor.execute("""
            SELECT id, content, category, importance, associations, created_at, last_accessed, access_count, embedding, emotional_data
            FROM thoughts
            WHERE content LIKE ?
            ORDER BY importance DESC, last_accessed DESC
            LIMIT ?
            """, (f"%{query}%", limit))
        
        rows = self.cursor.fetchall()
        thoughts = []
        
        for row in rows:
            thought = Thought(
                id=row[0],
                content=row[1],
                category=row[2],
                importance=row[3],
                associations=json.loads(row[4]),
                created_at=row[5],
                last_accessed=row[6],
                access_count=row[7],
                embedding=np.frombuffer(row[8], dtype=np.float32) if row[8] else None,
                metadata={"emotional_data": json.loads(row[9])} if row[9] else None
            )
            thoughts.append(thought)
            
            # Update access count and last accessed time
            self.cursor.execute("""
            UPDATE thoughts
            SET access_count = access_count + 1, last_accessed = ?
            WHERE id = ?
            """, (time.time(), thought.id))
        
        self.conn.commit()
        return thoughts
    
    def search_by_association(self, association: str, limit: int = 10) -> List[Thought]:
        """Search for thoughts by association.
        
        Args:
            association: The association to search for
            limit: Maximum number of results to return
            
        Returns:
            List of matching thoughts
        """
        self.cursor.execute("""
        SELECT t.id, t.content, t.category, t.importance, t.associations, t.created_at, t.last_accessed, t.access_count, t.embedding, t.emotional_data
        FROM thoughts t
        JOIN thought_associations ta ON t.id = ta.thought_id
        WHERE ta.association = ?
        ORDER BY t.importance DESC, t.last_accessed DESC
        LIMIT ?
        """, (association, limit))
        
        rows = self.cursor.fetchall()
        thoughts = []
        
        for row in rows:
            thought = Thought(
                id=row[0],
                content=row[1],
                category=row[2],
                importance=row[3],
                associations=json.loads(row[4]),
                created_at=row[5],
                last_accessed=row[6],
                access_count=row[7],
                embedding=np.frombuffer(row[8], dtype=np.float32) if row[8] else None,
                metadata={"emotional_data": json.loads(row[9])} if row[9] else None
            )
            thoughts.append(thought)
            
            # Update access count and last accessed time
            self.cursor.execute("""
            UPDATE thoughts
            SET access_count = access_count + 1, last_accessed = ?
            WHERE id = ?
            """, (time.time(), thought.id))
        
        self.conn.commit()
        return thoughts
    
    def get_recent_thoughts(self, limit: int = 10) -> List[Thought]:
        """Get the most recently accessed thoughts.
        
        Args:
            limit: Maximum number of results to return
            
        Returns:
            List of recent thoughts
        """
        self.cursor.execute("""
        SELECT id, content, category, importance, associations, created_at, last_accessed, access_count, embedding, emotional_data
        FROM thoughts
        ORDER BY last_accessed DESC
        LIMIT ?
        """, (limit,))
        
        rows = self.cursor.fetchall()
        thoughts = []
        
        for row in rows:
            thought = Thought(
                id=row[0],
                content=row[1],
                category=row[2],
                importance=row[3],
                associations=json.loads(row[4]),
                created_at=row[5],
                last_accessed=row[6],
                access_count=row[7],
                embedding=np.frombuffer(row[8], dtype=np.float32) if row[8] else None,
                metadata={"emotional_data": json.loads(row[9])} if row[9] else None
            )
            thoughts.append(thought)
        
        return thoughts
    
    def get_important_thoughts(self, threshold: float = 0.55, limit: int = 10) -> List[Thought]:
        """Get thoughts with importance above a threshold.
        
        Args:
            threshold: Minimum importance value (0.0 to 1.0)
            limit: Maximum number of results to return
            
        Returns:
            List of important thoughts
        """
        self.cursor.execute("""
        SELECT id, content, category, importance, associations, created_at, last_accessed, access_count, embedding, emotional_data
        FROM thoughts
        WHERE importance >= ?
        ORDER BY importance DESC
        LIMIT ?
        """, (threshold, limit))
        
        rows = self.cursor.fetchall()
        thoughts = []
        
        for row in rows:
            thought = Thought(
                id=row[0],
                content=row[1],
                category=row[2],
                importance=row[3],
                associations=json.loads(row[4]),
                created_at=row[5],
                last_accessed=row[6],
                access_count=row[7],
                embedding=np.frombuffer(row[8], dtype=np.float32) if row[8] else None,
                metadata={"emotional_data": json.loads(row[9])} if row[9] else None
            )
            thoughts.append(thought)
        
        return thoughts
    
    def update_thought(self, thought: Thought) -> bool:
        """Update an existing thought.
        
        Args:
            thought: The thought to update
            
        Returns:
            True if successful, False otherwise
        """
        if thought.id is None:
            return False
            
        # Update thought in database
        self.cursor.execute("""
        UPDATE thoughts
        SET content = ?, category = ?, importance = ?, associations = ?, last_accessed = ?, access_count = ?, embedding = ?, emotional_data = ?
        WHERE id = ?
        """, (
            thought.content,
            thought.category,
            thought.importance,
            json.dumps(thought.associations),
            thought.last_accessed,
            thought.access_count,
            thought.embedding.tobytes() if thought.embedding is not None else None,
            json.dumps(thought.metadata.get("emotional_data")) if thought.metadata else None,
            thought.id
        ))
        
        # Update associations
        self.cursor.execute("""
        DELETE FROM thought_associations
        WHERE thought_id = ?
        """, (thought.id,))
        
        for association in thought.associations:
            self.cursor.execute("""
            INSERT INTO thought_associations (thought_id, association)
            VALUES (?, ?)
            """, (thought.id, association))
        
        self.conn.commit()
        
        # Update in recent thoughts
        self._add_to_recent_thoughts(thought)
        
        return True
    
    def delete_thought(self, thought_id: int) -> bool:
        """Delete a thought from the database.
        
        Args:
            thought_id: The ID of the thought to delete
            
        Returns:
            True if successful, False otherwise
        """
        # Check if thought exists
        self.cursor.execute("""
        SELECT id FROM thoughts WHERE id = ?
        """, (thought_id,))
        
        if not self.cursor.fetchone():
            return False
            
        # Delete thought and associations (cascade will handle associations)
        self.cursor.execute("""
        DELETE FROM thoughts WHERE id = ?
        """, (thought_id,))
        
        self.conn.commit()
        
        # Remove from recent thoughts if present
        self.recent_thoughts = [t for t in self.recent_thoughts if t.id != thought_id]
        
        return True
    
    def _add_to_recent_thoughts(self, thought: Thought):
        """Add a thought to the recent thoughts cache.
        
        Args:
            thought: The thought to add
        """
        # Remove if already in recent thoughts
        self.recent_thoughts = [t for t in self.recent_thoughts if t.id != thought.id]
        
        # Add to front of list
        self.recent_thoughts.insert(0, thought)
        
        # Trim if too many
        if len(self.recent_thoughts) > self.max_recent_thoughts:
            self.recent_thoughts = self.recent_thoughts[:self.max_recent_thoughts]
    
    def backup_to_cloud(self, bucket_name: str, backup_path: str = None):
        """Backup the database to Google Cloud Storage.
        
        Args:
            bucket_name: Name of the GCS bucket
            backup_path: Path in the bucket to store the backup
        """
        try:
            # Close connection to allow backup
            self.close()
            
            # Generate backup path if not provided
            if not backup_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_path = f"mind_database_backup_{timestamp}.sqlite"
            
            # Create GCS client and upload file
            client = storage.Client()
            bucket = client.bucket(bucket_name)
            blob = bucket.blob(backup_path)
            
            blob.upload_from_filename(self.db_path)
            
            logger.info(f"Mind database backed up to gs://{bucket_name}/{backup_path}")
            
            # Reopen connection
            self.initialize_database()
            return True
        except Exception as e:
            logger.error(f"Failed to backup mind database: {e}")
            # Reopen connection in case of failure
            self.initialize_database()
            return False
    
    def restore_from_cloud(self, bucket_name: str, backup_path: str):
        """Restore the database from Google Cloud Storage.
        
        Args:
            bucket_name: Name of the GCS bucket
            backup_path: Path in the bucket to the backup file
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Close connection to allow restore
            self.close()
            
            # Create GCS client and download file
            client = storage.Client()
            bucket = client.bucket(bucket_name)
            blob = bucket.blob(backup_path)
            
            blob.download_to_filename(self.db_path)
            
            logger.info(f"Mind database restored from gs://{bucket_name}/{backup_path}")
            
            # Reopen connection
            self.initialize_database()
            return True
        except Exception as e:
            logger.error(f"Failed to restore mind database: {e}")
            # Reopen connection in case of failure
            self.initialize_database()
            return False
    
    def fast_learn(self, new_thought: Thought, related_thoughts: List[Thought] = None):
        """Implement fast learning by adjusting importance based on relationships.
        
        Args:
            new_thought: The new thought to learn
            related_thoughts: Optional list of related thoughts
        """
        # Extract emotional patterns from the thought content
        emotional_data = self._extract_emotional_patterns(new_thought.content)
        
        # If no related thoughts provided, find them based on associations and emotional patterns
        if related_thoughts is None:
            related_thoughts = []
            # Find by associations
            for association in new_thought.associations:
                related_thoughts.extend(self.search_by_association(association, limit=10))
            
            # Also find thoughts with similar emotional patterns
            if emotional_data:
                similar_emotional_thoughts = self._find_similar_emotional_thoughts(emotional_data, limit=5)
                related_thoughts.extend(similar_emotional_thoughts)
            
            # Remove duplicates
            unique_related = {}
            for thought in related_thoughts:
                if thought.id not in unique_related:
                    unique_related[thought.id] = thought
            related_thoughts = list(unique_related.values())
        
        # Store the emotional data with the thought
        if emotional_data:
            new_thought.metadata = new_thought.metadata or {}
            new_thought.metadata["emotional_data"] = emotional_data
        
        # Store the new thought
        new_id = self.store_thought(new_thought)
        
        # Update importance of related thoughts based on similarity with adaptive learning rate
        learning_rate = 0.15  # Increased from 0.1 for faster learning
        for related in related_thoughts:
            # Calculate semantic similarity (placeholder for more sophisticated implementation)
            content_similarity = self._calculate_content_similarity(new_thought.content, related.content)
            
            # Calculate association overlap
            association_overlap = len(set(related.associations) & set(new_thought.associations))
            
            # Calculate emotional similarity if available
            emotional_similarity = 0.0
            if emotional_data and hasattr(related, 'metadata') and related.metadata and 'emotional_data' in related.metadata:
                emotional_similarity = self._calculate_emotional_similarity(
                    emotional_data, related.metadata['emotional_data']
                )
            
            # Combined similarity score with weights
            similarity = (
                content_similarity * 0.4 + 
                min(association_overlap * 0.1, 0.3) + 
                emotional_similarity * 0.3
            )
            
            # Adaptive learning rate based on access frequency
            adaptive_rate = learning_rate * (1 + 0.15 * min(related.access_count, 12))
            
            # Apply importance boost with diminishing returns for frequently accessed thoughts
            importance_boost = min(similarity * adaptive_rate, 0.35)
            
            # Update the thought with new importance
            related.importance = min(related.importance + importance_boost, 1.0)
            self.update_thought(related)
            
            # Update associations bidirectionally for stronger connections
            self._strengthen_associations(new_thought, related)
        
        return new_id
    
    def _extract_emotional_patterns(self, content: str) -> Dict[str, float]:
        """Extract emotional patterns from text content.
        
        Args:
            content: The text content to analyze
            
        Returns:
            Dictionary of emotion types and their intensities
        """
        # Simple keyword-based emotion detection (placeholder for more sophisticated NLP)
        emotions = {
            "joy": ["happy", "joy", "delighted", "pleased", "glad", "excited"],
            "sadness": ["sad", "unhappy", "depressed", "down", "miserable", "gloomy"],
            "anger": ["angry", "mad", "furious", "outraged", "annoyed", "irritated"],
            "fear": ["afraid", "scared", "frightened", "terrified", "anxious", "worried"],
            "surprise": ["surprised", "amazed", "astonished", "shocked", "startled"],
            "disgust": ["disgusted", "revolted", "repulsed", "appalled"],
            "trust": ["trust", "believe", "faith", "confident", "assured"],
            "anticipation": ["anticipate", "expect", "look forward", "await"]
        }
        
        content_lower = content.lower()
        emotional_data = {}
        
        for emotion, keywords in emotions.items():
            intensity = 0.0
            for keyword in keywords:
                if keyword in content_lower:
                    # Increase intensity based on keyword count and position
                    count = content_lower.count(keyword)
                    position_factor = 1.2 if keyword in content_lower[:len(content_lower)//3] else 1.0
                    intensity += 0.25 * count * position_factor
            
            if intensity > 0.0:
                emotional_data[emotion] = min(1.0, intensity)
        
        return emotional_data
    
    def _find_similar_emotional_thoughts(self, emotional_data: Dict[str, float], limit: int = 5) -> List[Thought]:
        """Find thoughts with similar emotional patterns.
        
        Args:
            emotional_data: The emotional pattern to match
            limit: Maximum number of results
            
        Returns:
            List of thoughts with similar emotional patterns
        """
        # In a real implementation, this would query the database for similar emotional patterns
        # For now, we'll use a simple in-memory search of recent thoughts
        
        results = []
        for thought in self.recent_thoughts:
            if hasattr(thought, 'metadata') and thought.metadata and 'emotional_data' in thought.metadata:
                similarity = self._calculate_emotional_similarity(emotional_data, thought.metadata['emotional_data'])
                if similarity > 0.6:  # Threshold for similarity
                    results.append((thought, similarity))
        
        # Sort by similarity and return top results
        results.sort(key=lambda x: x[1], reverse=True)
        return [t[0] for t in results[:limit]]
    
    def _calculate_emotional_similarity(self, emotions1: Dict[str, float], emotions2: Dict[str, float]) -> float:
        """Calculate similarity between two emotional patterns.
        
        Args:
            emotions1: First emotional pattern
            emotions2: Second emotional pattern
            
        Returns:
            Similarity score between 0.0 and 1.0
        """
        # Find common emotions
        common_emotions = set(emotions1.keys()) & set(emotions2.keys())
        if not common_emotions:
            return 0.0
        
        # Calculate similarity based on intensity differences
        similarity = 0.0
        for emotion in common_emotions:
            intensity_diff = abs(emotions1[emotion] - emotions2[emotion])
            similarity += 1.0 - intensity_diff
        
        # Normalize by number of common emotions
        return similarity / len(common_emotions) if common_emotions else 0.0
    
    def _calculate_content_similarity(self, content1: str, content2: str) -> float:
        """Calculate semantic similarity between two text contents.
        
        Args:
            content1: First text content
            content2: Second text content
            
        Returns:
            Similarity score between 0.0 and 1.0
        """
        # Simple word overlap similarity (placeholder for embedding-based similarity)
        words1 = set(content1.lower().split())
        words2 = set(content2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union)
    
    def _strengthen_associations(self, thought1: Thought, thought2: Thought) -> None:
        """Strengthen associations between two thoughts bidirectionally.
        
        Args:
            thought1: First thought
            thought2: Second thought
        """
        # Add some of thought2's associations to thought1
        for assoc in thought2.associations[:3]:  # Limit to prevent excessive growth
            if assoc not in thought1.associations:
                thought1.associations.append(assoc)
        
        # Add some of thought1's associations to thought2
        for assoc in thought1.associations[:3]:
            if assoc not in thought2.associations:
                thought2.associations.append(assoc)
    
    def generate_associations(self, content: str) -> List[str]:
        """Generate associations for a thought based on content.
        
        Args:
            content: The thought content
            
        Returns:
            List of generated associations
        """
        # Simple implementation - extract keywords
        # In a real system, this would use NLP techniques
        words = content.lower().split()
        stopwords = {"the", "a", "an", "in", "on", "at", "to", "for", "with", "by", "of", "and", "or"}
        keywords = [word for word in words if word not in stopwords and len(word) > 3]
        
        # Deduplicate and take top 5
        unique_keywords = list(set(keywords))[:5]
        
        return unique_keywords

# Create a singleton instance
mind_db = MindDatabase()
