import logging
from typing import Dict, Optional, List, Any, Type
from core.agent_system import CognitiveAgent

logger = logging.getLogger(__name__)

class AgentManager:
    """Manages cognitive agents in the Pooler AI system."""
    
    def __init__(self):
        self.agents: Dict[str, CognitiveAgent] = {}
        self.agent_factories: Dict[str, Any] = {}
    
    def register_agent_factory(self, agent_type: str, factory_function: Any) -> None:
        """Register a factory function for creating agents of a specific type."""
        self.agent_factories[agent_type] = factory_function
        logger.info(f"Registered agent factory for type: {agent_type}")
    
    def create_agent(self, agent_id: str, agent_type: str, model_type: str = "PX1", **kwargs) -> CognitiveAgent:
        """Create a new agent using the appropriate factory function."""
        if agent_type not in self.agent_factories:
            logger.warning(f"Agent type '{agent_type}' not found. Using default cognitive agent.")
            from core.agent_system import create_agent
            agent = create_agent(agent_id, model_type)
        else:
            factory = self.agent_factories[agent_type]
            agent = factory(agent_id, model_type, **kwargs)
        
        # Register the agent
        self.register_agent(agent)
        
        return agent
    
    def register_agent(self, agent: CognitiveAgent) -> None:
        """Register a new agent with the manager."""
        if agent.agent_id in self.agents:
            logger.warning(f"Agent with ID {agent.agent_id} already exists. Overwriting.")
            
        self.agents[agent.agent_id] = agent
        logger.info(f"Registered agent with ID: {agent.agent_id}")
    
    def get_agent(self, agent_id: str) -> Optional[CognitiveAgent]:
        """Get an agent by its ID."""
        agent = self.agents.get(agent_id)
        if not agent:
            logger.warning(f"Agent with ID {agent_id} not found")
            return None
            
        return agent
    
    def remove_agent(self, agent_id: str) -> bool:
        """Remove an agent from the manager."""
        if agent_id not in self.agents:
            logger.warning(f"Cannot remove agent with ID {agent_id}: not found")
            return False
            
        del self.agents[agent_id]
        logger.info(f"Removed agent with ID: {agent_id}")
        return True
    
    def list_agents(self) -> List[Dict]:
        """List all registered agents."""
        return [
            {
                "agent_id": agent_id,
                "agent_type": agent.__class__.__name__,
                "model_type": agent.model_type,
                "learning_progress": agent.state.get('learning_progress', 0.0),
                "last_action_timestamp": agent.state.get('last_action_timestamp', 0)
            }
            for agent_id, agent in self.agents.items()
        ]
    
    def get_agent_count(self) -> int:
        """Get the number of registered agents."""
        return len(self.agents)
    
    def initialize(self) -> None:
        """Initialize the agent manager with default agent factories."""
        # Register the standard cognitive agent factory
        from core.agent_system import create_agent
        self.register_agent_factory("cognitive", create_agent)
        
        # Register the learning agent factory
        from core.learning_agents import create_learning_agent
        self.register_agent_factory("learning", create_learning_agent)
        
        logger.info("Agent manager initialized with default agent factories")

# Create a singleton instance
agent_manager = AgentManager()
