import os
import torch
import logging
import json
from pathlib import Path
from datetime import datetime
from google.cloud import storage
from model.llm import PX1LLM
from local_trainer import LocalTrainer

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def setup_gcs_credentials():
    """Setup Google Cloud Storage credentials"""
    # Create service account key file
    service_account_info = {
        "type": "service_account",
        "project_id": "ai-datasets-project",
        "client_email": "pooler-ai-training@ai-datasets-project.iam.gserviceaccount.com"
    }
    
    # Save credentials file
    creds_path = "/kaggle/working/gcs_credentials.json"
    with open(creds_path, "w") as f:
        json.dump(service_account_info, f)
    
    # Set environment variable
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = creds_path
    os.environ["GOOGLE_CLOUD_PROJECT"] = "ai-datasets-project"
    os.environ["POOLER_AI_BUCKET"] = "px1-dataset-v1"

def download_dataset_from_gcs():
    """Download dataset from Google Cloud Storage"""
    logger.info("Downloading dataset from GCS")
    
    # Initialize GCS client
    storage_client = storage.Client()
    bucket = storage_client.bucket("px1-dataset-v1")
    
    # Create dataset directory
    dataset_dir = "/kaggle/working/datasets"
    os.makedirs(dataset_dir, exist_ok=True)
    
    # Download all files from the training directory
    prefix = "training/dataset_v1/"
    blobs = bucket.list_blobs(prefix=prefix)
    
    for blob in blobs:
        # Create local directory structure
        local_path = os.path.join(dataset_dir, blob.name.replace(prefix, ""))
        os.makedirs(os.path.dirname(local_path), exist_ok=True)
        
        # Download file
        blob.download_to_filename(local_path)
        logger.info(f"Downloaded {blob.name} to {local_path}")
    
    return dataset_dir

def setup_kaggle_environment():
    """Setup Kaggle-specific configurations"""
    # Check if running on Kaggle
    if os.path.exists("/kaggle/working"):
        logger.info("Running on Kaggle environment")
        # Create necessary directories
        output_dirs = [
            "/kaggle/working/models",
            "/kaggle/working/outputs",
            "/kaggle/working/logs",
            "/kaggle/working/checkpoints"
        ]
        for dir_path in output_dirs:
            os.makedirs(dir_path, exist_ok=True)
            
        # Setup GCS access
        setup_gcs_credentials()
        
        # Download dataset
        dataset_dir = download_dataset_from_gcs()
        logger.info(f"Dataset downloaded to {dataset_dir}")
        
        return "/kaggle/working"
    return "."

def save_outputs(work_dir: str, job_id: str, metrics: dict):
    """Save training outputs and metrics"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Save metrics
    metrics_file = Path(work_dir) / "outputs" / f"metrics_{timestamp}.json"
    with open(metrics_file, "w") as f:
        json.dump(metrics, f, indent=2)
    
    # Save model checkpoint
    checkpoint_file = Path(work_dir) / "checkpoints" / f"model_{timestamp}.pt"
    torch.save({
        'job_id': job_id,
        'metrics': metrics,
        'timestamp': timestamp
    }, checkpoint_file)
    
    # Upload to GCS
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket("px1-models-v1")
        
        # Upload metrics
        metrics_blob = bucket.blob(f"training_outputs/{job_id}/metrics_{timestamp}.json")
        metrics_blob.upload_from_filename(str(metrics_file))
        
        # Upload checkpoint
        checkpoint_blob = bucket.blob(f"training_outputs/{job_id}/model_{timestamp}.pt")
        checkpoint_blob.upload_from_filename(str(checkpoint_file))
        
        logger.info(f"Uploaded outputs to GCS bucket px1-models-v1")
    except Exception as e:
        logger.warning(f"Failed to upload to GCS: {str(e)}")
    
    logger.info(f"Saved outputs to {work_dir}/outputs and {work_dir}/checkpoints")

def main():
    # Setup environment
    work_dir = setup_kaggle_environment()
    
    # Training configuration
    config = {
        'epochs': 3,
        'batch_size': 2,
        'learning_rate': 5e-5,
        'use_gpu': True,
        'save_checkpoints': True,
        'checkpoint_interval': 1000,  # Save every 1000 steps
        'output_dir': os.path.join(work_dir, 'outputs'),
        'model_dir': os.path.join(work_dir, 'models'),
        'checkpoint_dir': os.path.join(work_dir, 'checkpoints'),
        'dataset_dir': os.path.join(work_dir, 'datasets'),
        'model_params': {
            'vocab_size': 32000,
            'd_model': 1024,
            'num_heads': 16,
            'num_layers': 12,
            'd_ff': 4096,
            'dropout': 0.1,
            'max_seq_len': 2048
        }
    }
    
    # Initialize trainer
    trainer = LocalTrainer()
    
    try:
        # Start training
        job_dir = Path(work_dir) / "training_job"
        job_dir.mkdir(exist_ok=True)
        
        logger.info("Starting training job")
        job_id = trainer.start_training_job(config, str(job_dir))
        
        # Monitor training and save outputs
        while True:
            status = trainer.get_job_status(job_id)
            if status['state'] == 'COMPLETED':
                logger.info("Training completed successfully!")
                metrics = trainer.get_job_metrics(job_id)
                save_outputs(work_dir, job_id, metrics)
                break
            elif status['state'] == 'FAILED':
                logger.error(f"Training failed: {status.get('error')}")
                break
            
            # Log and save intermediate metrics
            metrics = trainer.get_job_metrics(job_id)
            if metrics:
                logger.info(f"Current metrics: {metrics}")
                save_outputs(work_dir, job_id, metrics)
    
    except KeyboardInterrupt:
        logger.info("Training interrupted by user")
        # Save final checkpoint before exiting
        metrics = trainer.get_job_metrics(job_id)
        save_outputs(work_dir, job_id, metrics)
    
    except Exception as e:
        logger.error(f"Training failed with error: {str(e)}")
        raise

if __name__ == "__main__":
    main()
