import logging
import time
from typing import Dict, List, Optional, Any, Tuple, Union
import numpy as np
from dataclasses import dataclass, field

from core.mind_database import mind_db, Thought
from core.thinking_engine import thinking_engine, ThinkingResult

logger = logging.getLogger(__name__)

@dataclass
class Perception:
    """Represents an agent's perception of its environment."""
    source: str  # Source of the perception (e.g., 'user_input', 'system_state', 'memory')
    content: Any  # The actual perception data
    timestamp: float = field(default_factory=time.time)
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Action:
    """Represents an action that the agent can take."""
    action_type: str  # Type of action (e.g., 'respond', 'search_memory', 'learn')
    parameters: Dict[str, Any]  # Parameters for the action
    priority: float = 1.0  # Priority of this action (higher = more important)
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class UtilityFunction:
    """Defines a utility function for evaluating actions."""
    name: str
    weight: float  # Importance weight of this utility function
    
    def evaluate(self, action: Action, perceptions: List[Perception], agent_state: Dict[str, Any]) -> float:
        """Evaluate the utility of an action given current perceptions and agent state."""
        raise NotImplementedError("Subclasses must implement this method")

class RelevanceUtility(UtilityFunction):
    """Evaluates how relevant an action is to the current perceptions."""
    def evaluate(self, action: Action, perceptions: List[Perception], agent_state: Dict[str, Any]) -> float:
        # Simple implementation - can be enhanced with more sophisticated relevance calculation
        if not perceptions:
            return 0.5  # Neutral if no perceptions
            
        # Get the most recent perception
        latest_perception = max(perceptions, key=lambda p: p.timestamp)
        
        # Check if the action parameters contain content that matches the perception
        if 'content' in action.parameters and isinstance(action.parameters['content'], str):
            # Simple text matching - could be replaced with semantic similarity
            action_content = action.parameters['content'].lower()
            perception_content = str(latest_perception.content).lower()
            
            # Calculate simple word overlap
            action_words = set(action_content.split())
            perception_words = set(perception_content.split())
            
            if not action_words:
                return 0.5
                
            overlap = len(action_words.intersection(perception_words)) / len(action_words)
            return min(1.0, overlap * 2)  # Scale up a bit, max at 1.0
        
        return 0.5  # Default neutral value

class NoveltyUtility(UtilityFunction):
    """Evaluates how novel or exploratory an action is."""
    def __init__(self, name: str, weight: float, history_size: int = 10):
        super().__init__(name, weight)
        self.history_size = history_size
    
    def evaluate(self, action: Action, perceptions: List[Perception], agent_state: Dict[str, Any]) -> float:
        # Check if we have action history
        action_history = agent_state.get('action_history', [])
        
        if not action_history:
            return 1.0  # Maximum novelty if no history
        
        # Count how many times this action type has been used recently
        recent_history = action_history[-self.history_size:] if len(action_history) > self.history_size else action_history
        type_count = sum(1 for a in recent_history if a.action_type == action.action_type)
        
        # Calculate novelty as inverse of frequency
        frequency = type_count / len(recent_history)
        novelty = 1.0 - frequency
        
        return novelty

class LearningUtility(UtilityFunction):
    """Evaluates the learning potential of an action."""
    def evaluate(self, action: Action, perceptions: List[Perception], agent_state: Dict[str, Any]) -> float:
        # Actions that explicitly involve learning get high utility
        if action.action_type in ['learn', 'store_thought', 'update_knowledge']:
            return 1.0
            
        # Check if this is a response action that might generate feedback
        if action.action_type == 'respond':
            # Complex responses have more learning potential
            if 'content' in action.parameters and isinstance(action.parameters['content'], str):
                content_length = len(action.parameters['content'])
                # Longer responses might have more learning potential (up to a point)
                return min(1.0, content_length / 500)
        
        # Default moderate learning potential
        return 0.4

class CognitiveAgent:
    """A cognitive, utility-based AI agent that perceives, thinks, and acts."""
    
    def __init__(self, agent_id: str, model_type: str = "PX1"):
        self.agent_id = agent_id
        self.model_type = model_type
        self.perceptions: List[Perception] = []
        self.state: Dict[str, Any] = {
            'action_history': [],
            'learning_progress': 0.0,
            'knowledge_gaps': [],
            'goals': [],
            'last_action_timestamp': 0.0
        }
        
        # Initialize utility functions
        self.utility_functions: List[UtilityFunction] = [
            RelevanceUtility("relevance", 0.4),
            NoveltyUtility("novelty", 0.2),
            LearningUtility("learning", 0.4)
        ]
    
    def perceive(self, source: str, content: Any, confidence: float = 1.0, metadata: Dict[str, Any] = None) -> None:
        """Add a new perception to the agent's perception list."""
        if metadata is None:
            metadata = {}
            
        perception = Perception(
            source=source,
            content=content,
            timestamp=time.time(),
            confidence=confidence,
            metadata=metadata
        )
        
        self.perceptions.append(perception)
        logger.info(f"Agent {self.agent_id} perceived: {source} - {content[:50]}..." if isinstance(content, str) else f"{source} - {type(content)}")
        
        # Limit the number of perceptions we store
        if len(self.perceptions) > 100:  # Arbitrary limit
            self.perceptions = self.perceptions[-100:]
    
    def think(self, query: str, context: Optional[str] = None) -> ThinkingResult:
        """Use the thinking engine to process perceptions and generate thoughts."""
        # Prepare context from recent perceptions if not provided
        if context is None:
            recent_perceptions = sorted(self.perceptions[-5:], key=lambda p: p.timestamp)  # Last 5 perceptions
            context = "\n".join([f"{p.source}: {p.content}" for p in recent_perceptions if isinstance(p.content, str)])
        
        # Use the thinking engine
        thinking_result = thinking_engine.think(query, context, self.model_type)
        
        # Store the thinking result as a thought if it's significant
        if thinking_result.confidence > 0.7:
            self._store_thought_from_thinking(thinking_result)
            
        return thinking_result
    
    def _store_thought_from_thinking(self, thinking_result: ThinkingResult) -> None:
        """Store significant thoughts from thinking results in the mind database."""
        # Create a new thought from the thinking result
        new_thought = Thought(
            id=None,  # Will be assigned by the database
            content=thinking_result.final_thought,
            category="agent_thinking",
            importance=thinking_result.confidence,
            associations=thinking_result.references,
            created_at=time.time(),
            last_accessed=time.time(),
            access_count=1
        )
        
        # Store the thought
        mind_db.store_thought(new_thought)
        
        # Update the agent's learning progress
        self.state['learning_progress'] += 0.05  # Small increment for each significant thought
    
    def generate_actions(self) -> List[Action]:
        """Generate possible actions based on current perceptions and state."""
        actions = []
        
        # Get recent perceptions
        recent_perceptions = sorted(self.perceptions[-3:], key=lambda p: p.timestamp)  # Last 3 perceptions
        
        if not recent_perceptions:
            # If no perceptions, generate an exploratory action
            actions.append(Action(
                action_type="explore",
                parameters={"strategy": "random"},
                priority=0.5
            ))
            return actions
        
        # Get the most recent perception
        latest_perception = recent_perceptions[-1]
        
        # Generate response action if the perception is from user input
        if latest_perception.source == "user_input" and isinstance(latest_perception.content, str):
            # Think about the response
            thinking_result = self.think(latest_perception.content)
            
            # Create a response action
            actions.append(Action(
                action_type="respond",
                parameters={
                    "content": thinking_result.final_thought if thinking_result.confidence > 0.6 else f"I'm thinking about {latest_perception.content}",
                    "confidence": thinking_result.confidence
                },
                priority=0.9  # High priority for user responses
            ))
        
        # Generate learning action if we've accumulated enough perceptions
        if len(self.perceptions) > 5:
            # Find patterns or connections between perceptions
            perception_contents = [p.content for p in recent_perceptions if isinstance(p.content, str)]
            if perception_contents:
                combined_content = " ".join(perception_contents)
                actions.append(Action(
                    action_type="learn",
                    parameters={
                        "content": combined_content,
                        "strategy": "pattern_recognition"
                    },
                    priority=0.7
                ))
        
        # Generate memory retrieval action
        if isinstance(latest_perception.content, str):
            actions.append(Action(
                action_type="retrieve_memory",
                parameters={
                    "query": latest_perception.content,
                    "limit": 3
                },
                priority=0.6
            ))
        
        # Generate exploratory action with lower priority
        actions.append(Action(
            action_type="explore",
            parameters={"strategy": "knowledge_gap"},
            priority=0.3
        ))
        
        return actions
    
    def evaluate_action_utility(self, action: Action) -> float:
        """Evaluate the utility of an action using the agent's utility functions."""
        total_utility = 0.0
        total_weight = 0.0
        
        for utility_func in self.utility_functions:
            utility_value = utility_func.evaluate(action, self.perceptions, self.state)
            total_utility += utility_value * utility_func.weight
            total_weight += utility_func.weight
        
        # Normalize by total weight
        if total_weight > 0:
            normalized_utility = total_utility / total_weight
        else:
            normalized_utility = 0.5  # Default neutral utility
            
        # Combine with the action's intrinsic priority
        combined_utility = (normalized_utility * 0.7) + (action.priority * 0.3)
        
        return combined_utility
    
    def select_best_action(self, actions: List[Action]) -> Optional[Action]:
        """Select the action with the highest utility."""
        if not actions:
            return None
            
        # Evaluate utility for each action
        action_utilities = [(action, self.evaluate_action_utility(action)) for action in actions]
        
        # Sort by utility (descending)
        action_utilities.sort(key=lambda x: x[1], reverse=True)
        
        # Return the action with the highest utility
        best_action = action_utilities[0][0]
        logger.info(f"Agent {self.agent_id} selected action: {best_action.action_type} with utility {action_utilities[0][1]:.2f}")
        
        return best_action
    
    def execute_action(self, action: Action) -> Dict[str, Any]:
        """Execute the selected action and return the result."""
        result = {"success": False, "data": None, "message": ""}
        
        try:
            if action.action_type == "respond":
                # Simulate response generation
                result["success"] = True
                result["data"] = action.parameters.get("content", "I don't know what to say.")
                result["message"] = "Response generated successfully"
                
            elif action.action_type == "learn":
                # Learn from the content
                content = action.parameters.get("content", "")
                if content:
                    # Create a thought from what we learned
                    new_thought = Thought(
                        id=None,
                        content=f"Learned: {content[:100]}...",
                        category="agent_learning",
                        importance=0.6,
                        associations=[],
                        created_at=time.time(),
                        last_accessed=time.time(),
                        access_count=1
                    )
                    mind_db.store_thought(new_thought)
                    
                    # Update learning progress
                    self.state['learning_progress'] += 0.1
                    
                    result["success"] = True
                    result["data"] = {"thought_id": new_thought.id, "learning_progress": self.state['learning_progress']}
                    result["message"] = "Learning action completed successfully"
                else:
                    result["message"] = "No content to learn from"
                    
            elif action.action_type == "retrieve_memory":
                # Retrieve memories from the mind database
                query = action.parameters.get("query", "")
                limit = action.parameters.get("limit", 3)
                
                if query:
                    thoughts = mind_db.search_thoughts(query, limit=limit)
                    result["success"] = True
                    result["data"] = [t.to_dict() for t in thoughts]
                    result["message"] = f"Retrieved {len(thoughts)} thoughts"
                else:
                    result["message"] = "No query provided for memory retrieval"
                    
            elif action.action_type == "explore":
                # Exploration action
                strategy = action.parameters.get("strategy", "random")
                
                if strategy == "knowledge_gap":
                    # Identify knowledge gaps
                    if not self.state.get('knowledge_gaps'):
                        # Simple placeholder - in a real system this would be more sophisticated
                        self.state['knowledge_gaps'] = ["quantum physics", "ancient history", "cooking techniques"]
                    
                    # Select a random knowledge gap to explore
                    import random
                    gap = random.choice(self.state['knowledge_gaps'])
                    
                    result["success"] = True
                    result["data"] = {"knowledge_gap": gap}
                    result["message"] = f"Exploring knowledge gap: {gap}"
                else:
                    # Random exploration
                    result["success"] = True
                    result["data"] = {"exploration": "random"}
                    result["message"] = "Random exploration completed"
            else:
                result["message"] = f"Unknown action type: {action.action_type}"
                
        except Exception as e:
            logger.error(f"Error executing action {action.action_type}: {str(e)}")
            result["message"] = f"Error: {str(e)}"
            
        # Record the action in history
        self.state['action_history'].append(action)
        self.state['last_action_timestamp'] = time.time()
        
        # Limit history size
        if len(self.state['action_history']) > 100:  # Arbitrary limit
            self.state['action_history'] = self.state['action_history'][-100:]
            
        return result
    
    def perceive_think_act(self, perception_source: str, perception_content: Any) -> Dict[str, Any]:
        """Complete perception-thinking-action cycle."""
        # 1. Perceive
        self.perceive(perception_source, perception_content)
        
        # 2. Generate possible actions
        possible_actions = self.generate_actions()
        
        # 3. Select the best action using utility functions
        best_action = self.select_best_action(possible_actions)
        
        # 4. Execute the selected action
        if best_action:
            result = self.execute_action(best_action)
        else:
            result = {"success": False, "message": "No action selected", "data": None}
            
        return result

# Utility function to create a new agent
def create_agent(agent_id: str, model_type: str = "PX1") -> CognitiveAgent:
    """Create and initialize a new cognitive agent."""
    agent = CognitiveAgent(agent_id, model_type)
    logger.info(f"Created new cognitive agent with ID: {agent_id}, model type: {model_type}")
    return agent
