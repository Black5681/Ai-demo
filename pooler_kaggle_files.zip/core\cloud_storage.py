from google.cloud import storage
from google.cloud import bigquery
import os
import json
from typing import Dict, List, Optional, Union
import torch

class CloudStorage:
    def __init__(self, project_id: str = "pooler-ai-project", bucket_name: str = "pooler-ai-datasets"):
        self.project_id = project_id
        self.bucket_name = bucket_name
        self.storage_client = storage.Client(project=project_id)
        self.bigquery_client = bigquery.Client(project=project_id)
        
        # Ensure bucket exists
        try:
            self.bucket = self.storage_client.get_bucket(bucket_name)
        except Exception:
            self.bucket = self.storage_client.create_bucket(bucket_name)
            print(f"Created new bucket: {bucket_name}")
    
    def upload_model(self, model_path: str, model_name: str) -> str:
        """Upload a model file to Google Cloud Storage."""
        destination_blob_name = f"models/{model_name}"
        blob = self.bucket.blob(destination_blob_name)
        
        blob.upload_from_filename(model_path)
        return f"gs://{self.bucket_name}/{destination_blob_name}"
    
    def download_model(self, model_name: str, destination_path: str) -> str:
        """Download a model file from Google Cloud Storage."""
        source_blob_name = f"models/{model_name}"
        blob = self.bucket.blob(source_blob_name)
        
        os.makedirs(os.path.dirname(destination_path), exist_ok=True)
        blob.download_to_filename(destination_path)
        return destination_path
    
    def upload_dataset(self, dataset_path: str, dataset_name: str) -> str:
        """Upload a dataset file to Google Cloud Storage."""
        destination_blob_name = f"datasets/{dataset_name}"
        blob = self.bucket.blob(destination_blob_name)
        
        blob.upload_from_filename(dataset_path)
        return f"gs://{self.bucket_name}/{destination_blob_name}"
    
    def list_available_models(self) -> List[str]:
        """List all available models in the storage."""
        blobs = self.storage_client.list_blobs(self.bucket_name, prefix="models/")
        return [blob.name.replace("models/", "") for blob in blobs]
    
    def list_available_datasets(self) -> List[str]:
        """List all available datasets in the storage."""
        blobs = self.storage_client.list_blobs(self.bucket_name, prefix="datasets/")
        return [blob.name.replace("datasets/", "") for blob in blobs]
    
    def save_model_metadata(self, model_name: str, metadata: Dict) -> None:
        """Save model metadata to BigQuery."""
        table_id = f"{self.project_id}.pooler_ai_metadata.models"
        
        rows_to_insert = [{
            "model_name": model_name,
            "version": metadata.get("version", "1.0"),
            "parameters": metadata.get("parameters", 10000000000),  # 10B default
            "architecture": metadata.get("architecture", "Dragon Transformer"),
            "training_steps": metadata.get("training_steps", 0),
            "created_at": metadata.get("created_at"),
            "model_type": metadata.get("model_type", "PX1"),
            "description": metadata.get("description", "")
        }]
        
        errors = self.bigquery_client.insert_rows_json(table_id, rows_to_insert)
        if errors:
            print(f"Errors inserting model metadata: {errors}")

# Helper function to load a 10B parameter model with efficient memory usage
def load_large_model(model_path: str, device: str = "cuda") -> torch.nn.Module:
    """Load a large 10B parameter model with efficient memory usage."""
    # Use checkpoint loading to efficiently load large models
    checkpoint = torch.load(model_path, map_location="cpu")
    
    # Determine model type from checkpoint
    if "px1" in model_path.lower():
        from model.transformer import PX1ChatModel
        model = PX1ChatModel(
            vocab_size=checkpoint.get("vocab_size", 50000),
            d_model=checkpoint.get("d_model", 2048),
            num_heads=checkpoint.get("num_heads", 16),
            num_layers=checkpoint.get("num_layers", 32),
            d_ff=checkpoint.get("d_ff", 8192),
        )
    else:  # IX1 model
        from model.transformer import IX1ImageModel
        model = IX1ImageModel(
            image_size=checkpoint.get("image_size", 256),
            d_model=checkpoint.get("d_model", 2048),
            num_heads=checkpoint.get("num_heads", 16),
            num_layers=checkpoint.get("num_layers", 32),
            d_ff=checkpoint.get("d_ff", 8192),
        )
    
    # Load state dict
    model.load_state_dict(checkpoint["model_state_dict"])
    
    # Move to appropriate device with memory efficiency
    if device == "cuda" and torch.cuda.is_available():
        # Use mixed precision for memory efficiency
        model = model.half().to(device)
    else:
        model = model.to(device)
    
    return model
